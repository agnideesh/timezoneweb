# 🚀 Setup Guide for Your Google Sheet

## ✅ Your Current Sheet Structure

Your Google Sheet already has these columns:
```
Product Name | Top Up Value (IDR) | % Increase in Tizo | Select % increase | Total Tizo Value (Auto-calculated) | Type of Deal | Start Date | End Date | Card Type | Venue | offer card
```

Perfect! The code has been updated to match your structure.

---

## 📋 Quick Setup (5 Steps)

### **Step 1: Install Dependencies**
Open terminal in your project folder and run:
```bash
npm install
```

### **Step 2: Copy the Updated Apps Script**
1. Open your Google Sheet: `https://docs.google.com/spreadsheets/d/1dVNRF2__Al8oKV6oiuubShbkERCG-DU0gqfQJKD-Oag/edit`
2. Click **Extensions** → **Apps Script**
3. Delete any existing code
4. Open the file `google-apps-script-updated.js` in your project
5. Copy **ALL** the code
6. Paste it into the Apps Script editor
7. Click **Save** (💾 icon)

### **Step 3: Deploy as Web App**
1. In Apps Script, click **Deploy** → **New deployment**
2. Click the gear icon ⚙️ → Select **Web app**
3. Configure:
   - **Execute as**: Me (your email)
   - **Who has access**: **Anyone**
4. Click **Deploy**
5. Click **Authorize access** and grant permissions
6. **COPY THE WEB APP URL** (it looks like `https://script.google.com/macros/s/AKfycby.../exec`)

### **Step 4: Update Your React App**
1. Open `src/config/api.ts` in your project
2. Replace this line:
   ```typescript
   export const GOOGLE_SHEETS_API_URL = 'YOUR_APPS_SCRIPT_URL_HERE';
   ```
   
   With your actual URL:
   ```typescript
   export const GOOGLE_SHEETS_API_URL = 'https://script.google.com/macros/s/AKfycby.../exec';
   ```
3. Save the file

### **Step 5: Run Your App**
```bash
npm run dev
```

---

## 🎯 How Data Maps

Your Google Sheet columns map to the app fields like this:

| Google Sheet Column | App Field |
|---------------------|-----------|
| Product Name | productName |
| Top Up Value (IDR) | cost |
| % Increase in Tizo | bonusPercent |
| Total Tizo Value (Auto-calculated) | tizoCredit |
| Type of Deal | category |
| Start Date | startDate |
| End Date | endDate |
| Card Type | cardType |
| Venue | venue |
| offer card | offerCardImage (captured preview) |

---

## ✨ What Happens When You Save

When you click **SAVE** in "Create New Offer":

1. ✅ Form data is collected
2. ✅ Preview card is captured as an image
3. ✅ Data is sent to Google Sheets
4. ✅ New row is added to your sheet
5. ✅ Data is also saved to localStorage (backup)

---

## 🧪 Test It

1. Run `npm run dev`
2. Login (admin/admin123)
3. Click "Create New Offer"
4. Fill in the form
5. Click **SAVE**
6. Check your Google Sheet - new row should appear!

---

## 🔍 Troubleshooting

### "Cannot find module 'html2canvas'"
```bash
npm install
```

### Data not appearing in Google Sheet
- Check browser console (F12) for errors
- Verify the Apps Script URL in `src/config/api.ts`
- Make sure you deployed with "Anyone" access
- Check that column headers match exactly

### CORS errors
- Redeploy the Apps Script
- Clear browser cache
- Make sure "Execute as: Me" is selected

---

## 📝 Notes

- The app uses **both** Google Sheets and localStorage
- If Google Sheets is unavailable, it falls back to localStorage
- The "offer card" column will store the captured preview image as base64
- You'll see "☁️ Google Sheets" in the header when connected

---

**Ready to go!** 🎉

Just complete the 5 steps above and your app will sync with your Google Sheet!
