# 🗄️ PostgreSQL Database Setup

Complete guide to set up Tizo Pricing with PostgreSQL backend.

---

## 📋 Prerequisites

1. **PostgreSQL** installed on your system
   - Download: https://www.postgresql.org/download/
   - Or use Docker: `docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=yourpassword postgres`

2. **Node.js** (v16 or higher)

---

## 🚀 Quick Setup (5 Steps)

### **Step 1: Install PostgreSQL**

**Windows:**
```bash
# Download installer from postgresql.org
# During installation, remember your password!
# Default port: 5432
```

**Using Docker (Recommended):**
```bash
docker run -d \
  --name tizo-postgres \
  -e POSTGRES_PASSWORD=admin123 \
  -e POSTGRES_DB=tizo_pricing \
  -p 5432:5432 \
  postgres:15
```

---

### **Step 2: Create Database**

Open **pgAdmin** or **psql**:

```sql
CREATE DATABASE tizo_pricing;
```

Or if using Docker, it's already created!

---

### **Step 3: Configure Backend**

Navigate to backend folder:
```bash
cd backend
```

Create `.env` file:
```bash
cp .env.example .env
```

Edit `.env` with your settings:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=tizo_pricing
DB_USER=postgres
DB_PASSWORD=your_password_here

PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
```

---

### **Step 4: Install Dependencies & Run Migrations**

```bash
# Install backend dependencies
npm install

# Run database migrations (creates tables)
npm run migrate
```

You should see:
```
🚀 Running database migrations...
📄 Running migration: 001_create_offers_table.sql
✅ Completed: 001_create_offers_table.sql
🎉 All migrations completed successfully!
```

---

### **Step 5: Start Backend Server**

```bash
npm run dev
```

You should see:
```
✅ Connected to PostgreSQL database
🚀 Tizo Pricing API Server
📡 Running on: http://localhost:3001
🗄️  Database: tizo_pricing
🌐 CORS enabled for: http://localhost:5173
```

---

## 🎯 Start Frontend

In a **new terminal**, go to project root:

```bash
# Install frontend dependencies (if not done)
npm install

# Start React app
npm run dev
```

Visit: **http://localhost:5173**

---

## ✅ Verify Everything Works

1. **Backend Health Check:**
   ```bash
   curl http://localhost:3001/health
   ```
   Should return: `{"status":"ok","message":"Tizo Pricing API is running"}`

2. **Open Frontend:**
   - Login with: `admin` / `admin123`
   - You should see "🗄️ PostgreSQL" in the header
   - Create a test offer - it should save to database!

3. **Check Database:**
   ```sql
   SELECT * FROM offers;
   ```

---

## 📊 Database Schema

The `offers` table includes:

| Column | Type | Description |
|--------|------|-------------|
| `id` | SERIAL | Auto-increment primary key |
| `product_name` | VARCHAR(255) | Offer name |
| `cost` | NUMERIC(10,2) | Top-up cost in IDR |
| `bonus_percent` | NUMERIC(5,2) | Bonus percentage |
| `tizo_credit` | NUMERIC(10,2) | Total Tizo credits |
| `category` | VARCHAR(100) | Deal category |
| `start_date` | DATE | Offer start date |
| `end_date` | DATE | Offer end date |
| `card_type` | VARCHAR(100) | Card type (New/Red/Blue/etc) |
| `venue` | TEXT[] | Array of venues |
| `remarks` | TEXT | Additional notes |
| `offer_card_image` | TEXT | Base64 image data |
| `character_icon` | TEXT | Character icon |
| `celebration_icon` | TEXT | Celebration icon |
| `bottom_left_icon` | TEXT | Bottom left badge |
| `bottom_right_icon` | TEXT | Bottom right badge |
| `created_at` | TIMESTAMP | Auto-set on creation |
| `updated_at` | TIMESTAMP | Auto-updated on change |

---

## 🔧 API Endpoints

All endpoints use: `http://localhost:3001/api`

### **Get All Offers**
```
GET /offers
Response: { success: true, data: [...] }
```

### **Get Single Offer**
```
GET /offers/:id
Response: { success: true, data: {...} }
```

### **Create Offer**
```
POST /offers
Body: { productName, cost, tizoCredit, ... }
Response: { success: true, data: { id: 1 } }
```

### **Update Offer**
```
PUT /offers/:id
Body: { productName, cost, ... }
Response: { success: true, message: "..." }
```

### **Delete Offer**
```
DELETE /offers/:id
Response: { success: true, message: "..." }
```

### **Bulk Update (Replace All)**
```
POST /offers/bulk
Body: [{ offer1 }, { offer2 }, ...]
Response: { success: true, count: 10 }
```

---

## 🎨 Features

### ✅ **What Works:**
- Full CRUD operations
- Real-time database sync
- Base64 image storage (up to 50MB per request)
- Automatic timestamps
- Transaction support for bulk updates
- LocalStorage fallback if database is offline
- Error handling with user-friendly messages

### 🚀 **Benefits Over Google Sheets:**
- ✅ No CORS issues
- ✅ No URL length limits
- ✅ Proper database with indexes
- ✅ Transaction support
- ✅ Much faster queries
- ✅ Supports large images
- ✅ Better data integrity
- ✅ Scalable to millions of records

---

## 🔍 Troubleshooting

### **Backend won't start:**
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```
**Fix:** Make sure PostgreSQL is running
```bash
# Check if running
docker ps  # if using Docker
# or
pg_isready -h localhost -p 5432
```

### **Migration fails:**
```
Error: database "tizo_pricing" does not exist
```
**Fix:** Create the database first
```sql
CREATE DATABASE tizo_pricing;
```

### **Frontend can't connect:**
```
Failed to connect to database. Using local data.
```
**Fix:** 
1. Check backend is running on port 3001
2. Check CORS settings in `.env`
3. Check browser console for errors

### **Images not saving:**
Images are stored as base64 in the database. If they're too large:
1. Check `express.json({ limit: '50mb' })` in `server.js`
2. Increase PostgreSQL `max_allowed_packet` if needed

---

## 🐳 Docker Compose (Optional)

Create `docker-compose.yml` in project root:

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: tizo_pricing
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: admin123
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  backend:
    build: ./backend
    ports:
      - "3001:3001"
    environment:
      DB_HOST: postgres
      DB_PORT: 5432
      DB_NAME: tizo_pricing
      DB_USER: postgres
      DB_PASSWORD: admin123
      FRONTEND_URL: http://localhost:5173
    depends_on:
      - postgres

volumes:
  postgres_data:
```

Run everything:
```bash
docker-compose up -d
```

---

## 📦 Production Deployment

### **Environment Variables:**
```env
NODE_ENV=production
DB_HOST=your-db-host.com
DB_PORT=5432
DB_NAME=tizo_pricing
DB_USER=your_user
DB_PASSWORD=your_secure_password
FRONTEND_URL=https://your-domain.com
```

### **Recommended Hosting:**
- **Database:** 
  - [Supabase](https://supabase.com) (Free PostgreSQL)
  - [Railway](https://railway.app)
  - [Neon](https://neon.tech)
  
- **Backend:**
  - [Railway](https://railway.app)
  - [Render](https://render.com)
  - [Fly.io](https://fly.io)

- **Frontend:**
  - [Vercel](https://vercel.com)
  - [Netlify](https://netlify.com)

---

## 🎉 You're Done!

Your Tizo Pricing app is now running with a proper PostgreSQL database!

**Next Steps:**
1. Customize the offers
2. Add more features
3. Deploy to production
4. Celebrate! 🎊
