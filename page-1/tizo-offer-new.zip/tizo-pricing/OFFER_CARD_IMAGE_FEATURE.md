# 📸 Offer Card Image Capture Feature

## ✅ What's Been Implemented

Your app now **automatically captures the preview card as an image** when you save or update an offer!

### How It Works:
1. When you create/edit an offer in the form
2. The preview card on the left is automatically captured as a PNG image
3. The image is saved as base64 data in the `offerCardImage` field
4. This image is stored in Google Sheets along with all other offer data

---

## 🚀 Setup Required

### Step 1: Install Dependencies
Run this command in your terminal:
```bash
npm install
```

This will install the `html2canvas` library that captures the preview card.

### Step 2: Update Your Google Sheet
Add one more column header to your Google Sheet (after the existing columns):
```
offerCardImage
```

Your complete column headers should now be:
```
productName | cost | tizoCredit | bonusPercent | category | remarks | cardType | venue | characterIcon | celebrationIcon | bottomLeftIcon | bottomRightIcon | offerCardImage
```

### Step 3: Redeploy Apps Script (Optional)
If you've already deployed your Apps Script:
1. The code in `google-apps-script.js` has been updated to include the new column
2. You can either:
   - **Option A**: Just add the column manually to your sheet (easier)
   - **Option B**: Redeploy the Apps Script for the initialization function

---

## 📋 What Changed

### Files Modified:

1. **`package.json`**
   - Added `html2canvas` dependency

2. **`src/types.ts`**
   - Added `offerCardImage?: string` field to `PricingProduct` interface

3. **`google-apps-script.js`**
   - Added `offerCardImage` to column headers in `initializeSheet()`

4. **`src/components/OfferBuilder.tsx`**
   - Imported `html2canvas` and `useRef`
   - Added `previewCardRef` to reference the preview card element
   - Created `capturePreviewCard()` function to capture the card as image
   - Updated `handleSubmit()` to capture image before saving
   - Added ref to the preview card div
   - Updated `handleReset()` to include `offerCardImage` field

---

## 🎯 How to Use

### Creating a New Offer:
1. Click "Create New Offer"
2. Fill in all the fields
3. See the live preview on the left
4. Click "SAVE"
5. **The preview card is automatically captured and saved!**

### Updating an Offer:
1. Click edit on any offer
2. Make your changes
3. See the updated preview
4. Click "UPDATE"
5. **The new preview card image is captured and saved!**

### Viewing the Captured Image:
The captured image is stored as base64 data in:
- Google Sheets (in the `offerCardImage` column)
- LocalStorage (as backup)

You can view it by:
- Opening your Google Sheet and checking the `offerCardImage` column
- The data will be a long base64 string starting with `data:image/png;base64,...`

---

## 🔧 Technical Details

### Image Capture:
- **Library**: html2canvas
- **Format**: PNG (base64 encoded)
- **Quality**: 2x scale for high resolution
- **Background**: Transparent

### Capture Process:
```javascript
1. User clicks SAVE/UPDATE
2. capturePreviewCard() is called
3. html2canvas captures the preview-card-neon div
4. Converts to base64 PNG
5. Adds to formData.offerCardImage
6. Saves to Google Sheets + localStorage
```

### Data Storage:
- **Google Sheets**: Stored in `offerCardImage` column
- **LocalStorage**: Included in cached offer data
- **Format**: `data:image/png;base64,iVBORw0KGgo...`

---

## 💡 Benefits

✅ **Visual Reference** - See exactly how each offer card looks
✅ **Audit Trail** - Track how offers appeared at different times
✅ **Easy Sharing** - Share offer card images with team
✅ **Automatic** - No manual screenshots needed
✅ **High Quality** - 2x resolution for crisp images

---

## ⚠️ Important Notes

### Image Size:
- Base64 images can be large (50-200KB per image)
- Google Sheets cells have a 50,000 character limit
- If your preview cards are very complex, consider:
  - Reducing the scale from 2 to 1
  - Using smaller badge images
  - Compressing images before upload

### Performance:
- Capturing happens asynchronously
- There's a brief delay (< 1 second) when saving
- The form won't close until capture is complete

### Browser Support:
- Works in all modern browsers
- Requires JavaScript enabled
- May not work in very old browsers

---

## 🐛 Troubleshooting

### "Cannot find module 'html2canvas'" Error:
```bash
npm install
```

### Image Not Capturing:
- Check browser console for errors
- Ensure the preview card is visible when saving
- Try with simpler badge images first

### Image Too Large for Google Sheets:
- Reduce scale in `capturePreviewCard()` from 2 to 1
- Use smaller badge images
- Consider storing images in a separate service

---

## 🎨 Customization

### Change Image Quality:
In `OfferBuilder.tsx`, modify the `capturePreviewCard()` function:

```typescript
const canvas = await html2canvas(previewCardRef.current, {
    backgroundColor: null,
    scale: 1, // Change from 2 to 1 for smaller files
    logging: false,
});
```

### Change Image Format:
```typescript
return canvas.toDataURL('image/jpeg', 0.8); // JPEG with 80% quality
```

---

## 🚀 Next Steps

1. **Run `npm install`** to install html2canvas
2. **Add the `offerCardImage` column** to your Google Sheet
3. **Test it** - Create a new offer and check the sheet!
4. **View the images** - Copy base64 data and paste in browser to see

Enjoy your automatic offer card screenshots! 📸✨
