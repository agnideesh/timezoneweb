-- Migration script to update offers table columns
-- Run this in your PostgreSQL database

-- 1. Rename character_icon to top_left_icon
ALTER TABLE public.offers RENAME COLUMN character_icon TO top_left_icon;

-- 2. Rename celebration_icon to top_right_icon
ALTER TABLE public.offers RENAME COLUMN celebration_icon TO top_right_icon;

-- 3. Drop remarks column (not needed)
ALTER TABLE public.offers DROP COLUMN IF EXISTS remarks;

-- Verify the changes
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'offers' 
ORDER BY ordinal_position;
