import type { PricingProduct } from '../types';
import { GOOGLE_SHEETS_API_URL } from '../config/api';

/**
 * Google Sheets Service - GET-ONLY VERSION
 * Uses GET requests with query parameters to avoid CORS preflight
 */

export class GoogleSheetsService {
    private static apiUrl = GOOGLE_SHEETS_API_URL;

    /**
     * Check if API is configured
     */
    static isConfigured(): boolean {
        return this.apiUrl !== 'YOUR_APPS_SCRIPT_URL_HERE' && this.apiUrl.length > 0;
    }

    /**
     * Fetch all offers from Google Sheets
     */
    static async fetchOffers(): Promise<PricingProduct[]> {
        if (!this.isConfigured()) {
            throw new Error('Google Sheets API URL not configured');
        }

        try {
            const url = `${this.apiUrl}?action=fetch&t=${Date.now()}`;
            const response = await fetch(url, {
                method: 'GET',
            });

            const result = await response.json();

            if (result.success) {
                return result.data;
            } else {
                throw new Error(result.error || 'Failed to fetch offers');
            }
        } catch (error) {
            console.error('Error fetching offers:', error);
            throw error;
        }
    }

    /**
     * Add a new offer to Google Sheets
     */
    static async addOffer(offer: PricingProduct): Promise<void> {
        if (!this.isConfigured()) {
            throw new Error('Google Sheets API URL not configured');
        }

        try {
            // Upload image to Drive if present
            let imageUrl = '';
            if (offer.offerCardImage && offer.offerCardImage.startsWith('data:image')) {
                console.log('📤 Uploading image to Google Drive...');
                imageUrl = await this.uploadImage(offer.offerCardImage, `offer-${Date.now()}.png`);
                console.log('✅ Image uploaded:', imageUrl);
            }

            // Prepare offer with image URL instead of base64
            const offerToSync = {
                ...offer,
                offerCardImage: imageUrl, // Store Drive URL
                characterIcon: '',
                celebrationIcon: '',
                bottomLeftIcon: '',
                bottomRightIcon: ''
            };

            const url = `${this.apiUrl}?action=add&data=${encodeURIComponent(JSON.stringify(offerToSync))}&t=${Date.now()}`;
            const response = await fetch(url, {
                method: 'GET',
            });

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to add offer');
            }
        } catch (error) {
            console.error('Error adding offer:', error);
            throw error;
        }
    }

    /**
     * Update an existing offer in Google Sheets
     */
    static async updateOffer(index: number, offer: PricingProduct): Promise<void> {
        if (!this.isConfigured()) {
            throw new Error('Google Sheets API URL not configured');
        }

        try {
            // Remove image data to avoid URL length limits
            const offerWithoutImages = {
                ...offer,
                offerCardImage: '',
                characterIcon: '',
                celebrationIcon: '',
                bottomLeftIcon: '',
                bottomRightIcon: ''
            };

            const url = `${this.apiUrl}?action=update&index=${index}&data=${encodeURIComponent(JSON.stringify(offerWithoutImages))}&t=${Date.now()}`;
            const response = await fetch(url, {
                method: 'GET',
            });

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to update offer');
            }
        } catch (error) {
            console.error('Error updating offer:', error);
            throw error;
        }
    }

    /**
     * Delete an offer from Google Sheets
     */
    static async deleteOffer(index: number): Promise<void> {
        if (!this.isConfigured()) {
            throw new Error('Google Sheets API URL not configured');
        }

        try {
            const url = `${this.apiUrl}?action=delete&index=${index}&t=${Date.now()}`;
            const response = await fetch(url, {
                method: 'GET',
            });

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to delete offer');
            }
        } catch (error) {
            console.error('Error deleting offer:', error);
            throw error;
        }
    }

    /**
     * Upload image to Google Drive and get URL
     */
    static async uploadImage(imageData: string, fileName: string): Promise<string> {
        if (!this.isConfigured()) {
            throw new Error('Google Sheets API URL not configured');
        }

        try {
            const response = await fetch(this.apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'uploadImage',
                    imageData: imageData,
                    fileName: fileName
                })
            });

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to upload image');
            }

            return result.data.imageUrl;
        } catch (error) {
            console.error('Error uploading image:', error);
            throw error;
        }
    }

    /**
     * Bulk update all offers (replace entire dataset)
     */
    static async bulkUpdateOffers(offers: PricingProduct[]): Promise<void> {
        if (!this.isConfigured()) {
            throw new Error('Google Sheets API URL not configured');
        }

        try {
            // Remove image data to avoid URL length limits
            const offersWithoutImages = offers.map(offer => ({
                ...offer,
                offerCardImage: '', // Don't sync images to Google Sheets
                characterIcon: '',
                celebrationIcon: '',
                bottomLeftIcon: '',
                bottomRightIcon: ''
            }));

            const url = `${this.apiUrl}?action=bulkUpdate&data=${encodeURIComponent(JSON.stringify(offersWithoutImages))}&t=${Date.now()}`;
            const response = await fetch(url, {
                method: 'GET',
            });

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to bulk update offers');
            }
        } catch (error) {
            console.error('Error bulk updating offers:', error);
            throw error;
        }
    }
}
