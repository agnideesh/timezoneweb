import type { PricingProduct } from '../types';

/**
 * API Service for PostgreSQL Backend
 * Handles all CRUD operations for offers
 */
class ApiService {
    private static apiUrl = 'http://localhost:3001/api';

    /**
     * Check if API is configured
     */
    static isConfigured(): boolean {
        return !!this.apiUrl;
    }

    /**
     * Fetch all offers from database
     */
    static async fetchOffers(): Promise<PricingProduct[]> {
        try {
            const response = await fetch(`${this.apiUrl}/offers`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (result.success) {
                return result.data;
            } else {
                throw new Error(result.error || 'Failed to fetch offers');
            }
        } catch (error) {
            console.error('Error fetching offers:', error);
            // Return empty array as fallback instead of throwing
            return [];
        }
    }

    /**
     * Get a single offer by ID
     */
    static async getOffer(id: number): Promise<PricingProduct> {
        try {
            const response = await fetch(`${this.apiUrl}/offers/${id}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();

            if (result.success) {
                return result.data;
            } else {
                throw new Error(result.error || 'Failed to fetch offer');
            }
        } catch (error) {
            console.error('Error fetching offer:', error);
            throw error;
        }
    }

    /**
     * Add a new offer to database
     */
    static async addOffer(offer: PricingProduct): Promise<{ id: number }> {
        try {
            const response = await fetch(`${this.apiUrl}/offers`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(offer)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to add offer');
            }

            return result.data;
        } catch (error) {
            console.error('Error adding offer:', error);
            throw error;
        }
    }

    /**
     * Update an existing offer in database
     */
    static async updateOffer(id: number, offer: PricingProduct): Promise<void> {
        try {
            const response = await fetch(`${this.apiUrl}/offers/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(offer)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to update offer');
            }
        } catch (error) {
            console.error('Error updating offer:', error);
            throw error;
        }
    }

    /**
     * Delete an offer from database
     */
    static async deleteOffer(id: number): Promise<void> {
        try {
            const response = await fetch(`${this.apiUrl}/offers/${id}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to delete offer');
            }
        } catch (error) {
            console.error('Error deleting offer:', error);
            throw error;
        }
    }

    /**
     * Toggle offer active/inactive status
     */
    static async toggleOfferActive(id: number, isActive: boolean): Promise<{ isActive: boolean }> {
        try {
            const response = await fetch(`${this.apiUrl}/offers/${id}/toggle-active`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ isActive })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to toggle offer status');
            }

            return result.data;
        } catch (error) {
            console.error('Error toggling offer status:', error);
            throw error;
        }
    }

    /**
     * Bulk update all offers (replace entire dataset)
     */
    static async bulkUpdateOffers(offers: PricingProduct[]): Promise<void> {
        try {
            const response = await fetch(`${this.apiUrl}/offers/bulk`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(offers)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.error || 'Failed to bulk update offers');
            }
        } catch (error) {
            console.error('Error bulk updating offers:', error);
            throw error;
        }
    }

    /**
     * Fetch Top Up Value options for dropdown from database
     */
    static async fetchTopUpValues(): Promise<number[]> {
        try {
            const response = await fetch(`${this.apiUrl}/topup-values`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            if (result.success) {
                return result.data;
            } else {
                throw new Error(result.error || 'Failed to fetch topup values');
            }
        } catch (error) {
            console.error('Error fetching topup values:', error);
            // Return fallback hardcoded values if API fails
            return [
                ...Array.from({ length: 200 }, (_, index) => (index + 1) * 1000),
                ...Array.from({ length: 38 }, (_, index) => (250 + index * 50) * 1000)
            ];
        }
    }

    /**
     * Fetch Bonus Percent options for dropdown from database
     */
    static async fetchBonusPercentOptions(): Promise<number[]> {
        try {
            const response = await fetch(`${this.apiUrl}/bonus-percent-options`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            if (result.success) {
                return result.data;
            } else {
                throw new Error(result.error || 'Failed to fetch bonus percent options');
            }
        } catch (error) {
            console.error('Error fetching bonus percent options:', error);
            // Return fallback hardcoded values if API fails
            return [
                ...Array.from({ length: 10 }, (_, i) => (i + 1) * 5),        // 5-50 step 5
                ...Array.from({ length: 10 }, (_, i) => 55 + i * 5),         // 55-100 step 5
                ...Array.from({ length: 20 }, (_, i) => 110 + i * 10)        // 110-300 step 10
            ];
        }
    }

    // Fetch all card offers from database
    static async fetchCardOffers(): Promise<{ id: string; name: string; description: string }[]> {
        try {
            const response = await fetch(`${this.apiUrl}/card-offers`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            if (data.success) {
                return data.data;
            }
            return [];
        } catch (error) {
            console.error('Error fetching card offers:', error);
            return [];
        }
    }

    // Update a card offer description
    static async updateCardOffer(id: string, description: string): Promise<boolean> {
        try {
            const response = await fetch(`${this.apiUrl}/card-offers/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ description })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.success;
        } catch (error) {
            console.error('Error updating card offer:', error);
            return false;
        }
    }
}

export default ApiService;
