import type { CategoryType } from '../types';

interface CategoryFilterProps {
    categories: string[];
    selectedCategory: CategoryType;
    onCategoryChange: (category: CategoryType) => void;
}

export const CategoryFilter = ({
    categories,
    selectedCategory,
    onCategoryChange
}: CategoryFilterProps) => {
    return (
        <div className="category-filter">
            <h3 className="filter-title">Filter by Category</h3>
            <div className="filter-buttons">
                {categories.map((category) => (
                    <button
                        key={category}
                        className={`filter-btn ${selectedCategory === category ? 'active' : ''}`}
                        onClick={() => onCategoryChange(category as CategoryType)}
                    >
                        {category}
                    </button>
                ))}
            </div>
        </div>
    );
};
