import { useState, type FormEvent } from 'react';
import { useAuth } from '../hooks/useAuth';
import { FaLock, FaUser, FaKey } from 'react-icons/fa';
import './Login.css';

interface LoginProps {
    onLoginSuccess: () => void;
}

export const Login = ({ onLoginSuccess }: LoginProps) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { login } = useAuth();

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        setError('');

        if (login(username, password)) {
            onLoginSuccess();
        } else {
            setError('Invalid username or password');
        }
    };

    return (
        <div className="login-container">
            <div className="login-background">
                <div className="login-card">
                    <button
                        type="button"
                        className="quick-login-button"
                        aria-label="Quick admin login"
                        onClick={() => {
                            setError('');
                            if (login('admin', 'admin123')) {
                                onLoginSuccess();
                            } else {
                                setError('Invalid username or password');
                            }
                        }}
                    >
                        <FaKey />
                    </button>
                    <div className="login-header">
                        <h1 className="login-title">
                            Timezone Offer Creator
                        </h1>
                        <p className="login-subtitle">Sign in to manage offers</p>
                    </div>

                    <form onSubmit={handleSubmit} className="login-form">
                        <div className="form-group">
                            <label htmlFor="username">
                                <FaUser /> Username
                            </label>
                            <input
                                type="text"
                                id="username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                placeholder="Enter username"
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="password">
                                <FaLock /> Password
                            </label>
                            <input
                                type="password"
                                id="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="Enter password"
                                required
                            />
                        </div>

                        {error && <div className="error-message">{error}</div>}

                        <button type="submit" className="login-button">
                            Sign In
                        </button>

                        <div className="demo-credentials">
                            <small>
                                Demo: <strong>admin</strong> / <strong>admin123</strong>
                            </small>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
