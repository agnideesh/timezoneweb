import { useState, useEffect } from 'react';
import './WorkflowBuilder.css';
import { useAuth } from '../hooks/useAuth';
import { OfferBuilder } from './OfferBuilder';
import brandLogo from '../assets/aisensum logo fixed-04.png';
import ApiService from '../services/apiService';

// Card images (fallback)
import redCardImage from '../assets/card offer/welcome card.png';
import blueCardImage from '../assets/card offer/blue elite.png';
import goldCardImage from '../assets/card offer/gold.png';
import platinumCardImage from '../assets/card offer/platinum - dark.png';

type TabType = 'cardoffer' | 'offers';

interface CardOfferInfo {
    id: string;
    name: string;
    image: string;
    description: string;
    isEditing: boolean;
    isSaving?: boolean;
}

// Image mapping for card offers
const cardImageMap: Record<string, string> = {
    'red': redCardImage,
    'blue': blueCardImage,
    'gold': goldCardImage,
    'platinum': platinumCardImage,
};

export const WorkflowBuilder = () => {
    const { logout } = useAuth();
    const [activeTab, setActiveTab] = useState<TabType>('cardoffer');
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    // Card offer state with editable descriptions
    const [cardOffers, setCardOffers] = useState<CardOfferInfo[]>([
        { id: 'red', name: 'Red (Welcome)', image: redCardImage, description: '', isEditing: true },
        { id: 'blue', name: 'Blue Elite', image: blueCardImage, description: '', isEditing: true },
        { id: 'gold', name: 'Gold', image: goldCardImage, description: '', isEditing: true },
        { id: 'platinum', name: 'Platinum', image: platinumCardImage, description: '', isEditing: true },
    ]);

    // Fetch card offers from database on mount
    useEffect(() => {
        const loadCardOffers = async () => {
            setIsLoading(true);
            const data = await ApiService.fetchCardOffers();
            if (data.length > 0) {
                setCardOffers(data.map(offer => ({
                    id: offer.id,
                    name: offer.name,
                    image: cardImageMap[offer.id] || redCardImage,
                    description: offer.description,
                    isEditing: !offer.description, // Start in edit mode if no description
                })));
            }
            setIsLoading(false);
        };
        loadCardOffers();
    }, []);

    const handleDescriptionChange = (cardId: string, value: string) => {
        setCardOffers(prev => prev.map(card =>
            card.id === cardId ? { ...card, description: value } : card
        ));
    };

    const toggleEditMode = (cardId: string) => {
        setCardOffers(prev => prev.map(card =>
            card.id === cardId ? { ...card, isEditing: !card.isEditing } : card
        ));
    };

    const handleSave = async (cardId: string) => {
        const card = cardOffers.find(c => c.id === cardId);
        if (card) {
            // Set saving state
            setCardOffers(prev => prev.map(c =>
                c.id === cardId ? { ...c, isSaving: true } : c
            ));

            // Save to database
            const success = await ApiService.updateCardOffer(cardId, card.description);

            if (success) {
                alert(`${card.name} information saved!`);
                setCardOffers(prev => prev.map(c =>
                    c.id === cardId ? { ...c, isEditing: false, isSaving: false } : c
                ));
            } else {
                alert(`Failed to save ${card.name}. Please try again.`);
                setCardOffers(prev => prev.map(c =>
                    c.id === cardId ? { ...c, isSaving: false } : c
                ));
            }
        }
    };

    const tabs = [
        { id: 'cardoffer' as TabType, label: 'Card Offer' },
        { id: 'offers' as TabType, label: 'Offer Builder' }
    ];

    return (
        <div className="workflow-builder-container">
            <header className="builder-header">
                <div className="builder-title-block">
                    <h1 className="builder-title">Timezone Offer Creator</h1>
                    <img src={brandLogo} alt="Timezone Offer Creator" className="builder-logo" />
                </div>
                <button onClick={logout} className="logout-btn">Logout</button>
            </header>

            <div className="workflow-layout">
                {/* Side Panel */}
                <aside className={`workflow-sidebar ${isSidebarCollapsed ? 'collapsed' : ''}`}>
                    <button
                        className="sidebar-toggle"
                        onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                        title={isSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                    >
                        <span className="arrow">{isSidebarCollapsed ? '>' : '<'}</span>
                    </button>
                    {!isSidebarCollapsed && (
                        <nav className="workflow-tabs">
                            {tabs.map(tab => (
                                <button
                                    key={tab.id}
                                    className={`tab-button ${activeTab === tab.id ? 'active' : ''}`}
                                    onClick={() => setActiveTab(tab.id)}
                                >
                                    {tab.label}
                                </button>
                            ))}
                        </nav>
                    )}
                </aside>

                {/* Main Content */}
                <main className="workflow-main">
                    {activeTab === 'cardoffer' && (
                        <section className="config-section">
                            <h2>Card Offer</h2>
                            <p className="section-description">Configure offer information for each card type</p>

                            {isLoading ? (
                                <div className="loading-indicator">Loading card offers...</div>
                            ) : (
                                <div className="card-offers-grid">
                                    {cardOffers.map(card => (
                                        <div key={card.id} className={`card-offer-panel card-${card.id}`}>
                                            <h3 className="card-offer-title">{card.name}</h3>
                                            <div className="card-offer-image-wrapper">
                                                <img
                                                    src={card.image}
                                                    alt={card.name}
                                                    className="card-offer-image"
                                                />
                                            </div>
                                            <div className="card-offer-content">
                                                <label>Offer Information</label>
                                                <textarea
                                                    value={card.description}
                                                    onChange={(e) => handleDescriptionChange(card.id, e.target.value)}
                                                    placeholder={`Enter offer details for ${card.name}...`}
                                                    disabled={!card.isEditing || card.isSaving}
                                                    className={!card.isEditing ? 'disabled' : ''}
                                                    rows={4}
                                                />
                                                <div className="card-offer-actions">
                                                    {card.isEditing ? (
                                                        <button
                                                            className="save-card-btn"
                                                            onClick={() => handleSave(card.id)}
                                                            disabled={card.isSaving}
                                                        >
                                                            {card.isSaving ? '⏳ Saving...' : '💾 Save'}
                                                        </button>
                                                    ) : (
                                                        <button
                                                            className="edit-card-btn"
                                                            onClick={() => toggleEditMode(card.id)}
                                                        >
                                                            ✏️ Edit
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </section>
                    )}

                    {activeTab === 'offers' && (
                        <div className="offer-builder-wrapper">
                            <OfferBuilder />
                        </div>
                    )}
                </main>
            </div>
        </div >
    );
};
