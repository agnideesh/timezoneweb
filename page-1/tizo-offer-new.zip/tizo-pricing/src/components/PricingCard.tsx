import type { PricingProduct } from '../types';

interface PricingCardProps {
    product: PricingProduct;
}

export const PricingCard = ({ product }: PricingCardProps) => {
    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(price);
    };

    const getCategoryColor = (category: string) => {
        const colors: { [key: string]: string } = {
            'Starter deal': 'from-blue-500 to-cyan-500',
            'booster': 'from-green-500 to-emerald-500',
            'Power deal': 'from-purple-500 to-pink-500',
            'Mega deal': 'from-orange-500 to-red-500',
            'Voucher': 'from-teal-500 to-cyan-500',
            'OOD/OOH/Xmas deal': 'from-yellow-500 to-orange-500'
        };
        return colors[category] || 'from-gray-500 to-gray-700';
    };

    const isSpecialDeal = product.bonusPercent >= 80;

    return (
        <div className={`pricing-card ${isSpecialDeal ? 'special-deal' : ''}`}>
            <div className={`category-badge bg-gradient-to-r ${getCategoryColor(product.category)}`}>
                {product.category}
            </div>

            {isSpecialDeal && (
                <div className="special-badge">
                    🔥 HOT DEAL
                </div>
            )}

            <h3 className="product-name">{product.productName}</h3>

            <div className="price-section">
                <div className="price">{formatPrice(product.cost)}</div>
                <div className="credit-amount">
                    <span className="credit-value">{product.tizoCredit}</span>
                    <span className="credit-label">Tizo Credits</span>
                </div>
            </div>

            {product.bonusPercent > 0 && (
                <div className="bonus-badge">
                    +{product.bonusPercent}% BONUS
                </div>
            )}

            {product.remarks && (
                <div className="remarks">
                    ℹ️ {product.remarks}
                </div>
            )}

            <button className="buy-button">
                Get Now
            </button>
        </div>
    );
};
