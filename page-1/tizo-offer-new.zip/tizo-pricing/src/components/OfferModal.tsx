import { useState, useEffect } from 'react';
import type { FormEvent } from 'react';
import type { PricingProduct } from '../types';
import { FaTimes } from 'react-icons/fa';
import './OfferModal.css';

interface OfferModalProps {
    offer?: PricingProduct;
    onSave: (offer: PricingProduct) => void;
    onClose: () => void;
}

export const OfferModal = ({ offer, onSave, onClose }: OfferModalProps) => {
    const [formData, setFormData] = useState<PricingProduct>({
        productName: '',
        cost: 0,
        tizoCredit: 0,
        bonusPercent: 0,
        category: 'Starter deal',
        remarks: '',
        cardType: 'ALL',
        venue: []
    });

    useEffect(() => {
        if (offer) {
            setFormData(offer);
        }
    }, [offer]);

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    const handleChange = (field: keyof PricingProduct, value: string | number) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                    <h2>{offer ? 'Edit Offer' : 'Add New Offer'}</h2>
                    <button onClick={onClose} className="close-button">
                        <FaTimes />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="offer-form">
                    <div className="form-row">
                        <div className="form-field">
                            <label htmlFor="productName">Product Name *</label>
                            <input
                                type="text"
                                id="productName"
                                value={formData.productName}
                                onChange={(e) => handleChange('productName', e.target.value)}
                                placeholder="e.g., Fun 100K Get 110 Tz"
                                required
                            />
                        </div>
                    </div>

                    <div className="form-row">
                        <div className="form-field">
                            <label htmlFor="cost">Cost (IDR) *</label>
                            <input
                                type="number"
                                id="cost"
                                value={formData.cost === 0 ? '' : formData.cost}
                                onFocus={(e) => e.target.select()}
                                onChange={(e) => handleChange('cost', Number(e.target.value))}
                                placeholder="100000"
                                min="0"
                                required
                            />
                        </div>

                        <div className="form-field">
                            <label htmlFor="tizoCredit">Tizo Credit *</label>
                            <input
                                type="number"
                                id="tizoCredit"
                                value={formData.tizoCredit === 0 ? '' : formData.tizoCredit}
                                onFocus={(e) => e.target.select()}
                                onChange={(e) => handleChange('tizoCredit', Number(e.target.value))}
                                placeholder="110"
                                min="0"
                                required
                            />
                        </div>
                    </div>

                    <div className="form-row">
                        <div className="form-field">
                            <label htmlFor="bonusPercent">Bonus Percentage *</label>
                            <input
                                type="number"
                                id="bonusPercent"
                                value={formData.bonusPercent === 0 ? '' : formData.bonusPercent}
                                onFocus={(e) => e.target.select()}
                                onChange={(e) => handleChange('bonusPercent', Number(e.target.value))}
                                placeholder="10"
                                min="0"
                                max="200"
                                step="0.1"
                                required
                            />
                        </div>

                        <div className="form-field">
                            <label htmlFor="category">Category *</label>
                            <select
                                id="category"
                                value={formData.category}
                                onChange={(e) => handleChange('category', e.target.value)}
                                required
                            >
                                <option value="Starter deal">Starter deal</option>
                                <option value="booster">Booster</option>
                                <option value="Power deal">Power deal</option>
                                <option value="Mega deal">Mega deal</option>
                                <option value="Voucher">Voucher</option>
                                <option value="OOD/OOH/Xmas deal">OOD/OOH/Xmas deal</option>
                            </select>
                        </div>
                    </div>

                    <div className="form-row">
                        <div className="form-field">
                            <label htmlFor="remarks">Remarks</label>
                            <textarea
                                id="remarks"
                                value={formData.remarks}
                                onChange={(e) => handleChange('remarks', e.target.value)}
                                placeholder="Optional notes or restrictions"
                                rows={3}
                            />
                        </div>
                    </div>

                    <div className="form-actions">
                        <button type="button" onClick={onClose} className="cancel-button">
                            Cancel
                        </button>
                        <button type="submit" className="save-button">
                            {offer ? 'Update Offer' : 'Add Offer'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
