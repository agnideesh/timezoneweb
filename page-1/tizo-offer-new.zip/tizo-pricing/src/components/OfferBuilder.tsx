import { useState, useMemo, useRef, useEffect } from 'react';
import type { PricingProduct } from '../types';
import { FaTrash, FaEdit, FaDownload, FaSyncAlt } from 'react-icons/fa';
import { useOffers } from '../hooks/useOffers';
import { useAuth } from '../hooks/useAuth';
import ApiService from '../services/apiService';
import html2canvas from 'html2canvas';
import './OfferBuilder.css';

// Card template images
import cardTemplate1 from '../assets/offer card/OOH_OOD.png';
import cardTemplate2 from '../assets/offer card/OOH_OOD2.png';
import cardTemplate3 from '../assets/offer card/OOH_OOD3 .png';
import cardTemplateBlue from '../assets/offer card/BIG BUTTON BLUE .png';
import cardTemplateGreen from '../assets/offer card/BIG BUTTON GREEN.png';
import cardTemplateOrange from '../assets/offer card/BIG BUTTON ORANGE .png';
import cardTemplatePink from '../assets/offer card/BIG BUTTON PINK .png';
import cardTemplateTosca from '../assets/offer card/BIG BUTTON TOSCA.png';
import cardTemplateYellow from '../assets/offer card/BIG BUTTON YELLOW .png';

const CARD_TEMPLATES = [
    { id: 'pink', name: 'Pink Neon', image: cardTemplate1 },
    { id: 'gold', name: 'Golden', image: cardTemplate2 },
    { id: 'green', name: 'Green Gold', image: cardTemplate3 },
    { id: 'blue', name: 'Blue', image: cardTemplateBlue },
    { id: 'btn-green', name: 'Green', image: cardTemplateGreen },
    { id: 'orange', name: 'Orange', image: cardTemplateOrange },
    { id: 'btn-pink', name: 'Pink', image: cardTemplatePink },
    { id: 'tosca', name: 'Tosca', image: cardTemplateTosca },
    { id: 'yellow', name: 'Yellow', image: cardTemplateYellow },
];

const INITIAL_TEMPLATES_COUNT = 3;

// Fallback values in case API fails
const FALLBACK_TOP_UP_VALUES: number[] = [
    ...Array.from({ length: 200 }, (_, index) => (index + 1) * 1000),
    ...Array.from({ length: 38 }, (_, index) => (250 + index * 50) * 1000)
];
const FALLBACK_BONUS_PERCENT: number[] = [
    ...Array.from({ length: 10 }, (_, i) => (i + 1) * 5),        // 5-50 step 5
    ...Array.from({ length: 10 }, (_, i) => 55 + i * 5),         // 55-100 step 5
    ...Array.from({ length: 20 }, (_, i) => 110 + i * 10)        // 110-300 step 10
];
type SortableColumn = 'productName' | 'cost' | 'tizoCredit' | 'cardType';

export const OfferBuilder = () => {
    const { offers, addOffer, updateOffer, deleteOffer, refreshFromDatabase, isLoading, isSyncing, syncError } = useOffers();
    const { logout } = useAuth();
    const [selectedOfferIndex, setSelectedOfferIndex] = useState<number | null>(null);
    const [filterType, setFilterType] = useState<'All' | 'OOH' | 'OOD' | 'Voucher'>('All');
    const [tableSearchTerm, setTableSearchTerm] = useState('');
    const [cardFilter, setCardFilter] = useState<string>('All');
    const [activeFilter, setActiveFilter] = useState<'all' | 'active' | 'inactive'>('all');
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [sortColumn, setSortColumn] = useState<SortableColumn | null>(null);
    const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
    const [isPreviewOpen, setIsPreviewOpen] = useState(false);
    const [previewOfferIndex, setPreviewOfferIndex] = useState<number | null>(null);
    const previewCardRef = useRef<HTMLDivElement>(null);
    const [selectedTemplate, setSelectedTemplate] = useState<string>('pink');
    const [showAllTemplates, setShowAllTemplates] = useState(false);
    const [showLimitPopup, setShowLimitPopup] = useState(false);
    const [limitMessage, setLimitMessage] = useState('');

    // Dropdown options fetched from database
    const [topUpValueOptions, setTopUpValueOptions] = useState<number[]>(FALLBACK_TOP_UP_VALUES);
    const [bonusPercentOptions, setBonusPercentOptions] = useState<number[]>(FALLBACK_BONUS_PERCENT);

    // Validation state for inputs
    const [costInputValue, setCostInputValue] = useState<string>('');
    const [bonusInputValue, setBonusInputValue] = useState<string>('');
    const [isCostValid, setIsCostValid] = useState<boolean>(true);
    const [isBonusValid, setIsBonusValid] = useState<boolean>(true);

    // Dropdown visibility state
    const [showCostDropdown, setShowCostDropdown] = useState<boolean>(false);
    const [showBonusDropdown, setShowBonusDropdown] = useState<boolean>(false);
    const costDropdownRef = useRef<HTMLDivElement>(null);
    const bonusDropdownRef = useRef<HTMLDivElement>(null);

    // Close dropdowns when clicking outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (costDropdownRef.current && !costDropdownRef.current.contains(event.target as Node)) {
                setShowCostDropdown(false);
            }
            if (bonusDropdownRef.current && !bonusDropdownRef.current.contains(event.target as Node)) {
                setShowBonusDropdown(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    // Fetch dropdown options from database on mount
    useEffect(() => {
        const loadDropdownOptions = async () => {
            const [topUpValues, bonusPercents] = await Promise.all([
                ApiService.fetchTopUpValues(),
                ApiService.fetchBonusPercentOptions()
            ]);
            setTopUpValueOptions(topUpValues);
            setBonusPercentOptions(bonusPercents);
        };
        loadDropdownOptions();
    }, []);

    // Filter options based on input value
    const filteredTopUpOptions = useMemo(() => {
        if (!costInputValue) return topUpValueOptions;
        return topUpValueOptions.filter(val => String(val).includes(costInputValue));
    }, [costInputValue, topUpValueOptions]);

    const filteredBonusOptions = useMemo(() => {
        if (!bonusInputValue) return bonusPercentOptions;
        return bonusPercentOptions.filter(val => String(val).includes(bonusInputValue));
    }, [bonusInputValue, bonusPercentOptions]);

    // Validate and handle cost input change
    const handleCostInputChange = (value: string) => {
        setCostInputValue(value);
        setShowCostDropdown(true);
        const numValue = Number(value.replace(/[^0-9]/g, ''));
        if (value === '' || isNaN(numValue)) {
            setIsCostValid(true); // Empty is valid (will be caught by required)
            handleChange('cost', 0);
            return;
        }
        const isValid = topUpValueOptions.includes(numValue);
        setIsCostValid(isValid);
        if (isValid) {
            handleChange('cost', numValue);
        } else {
            handleChange('cost', numValue); // Still update for display, but mark invalid
        }
    };

    // Validate and handle bonus input change
    const handleBonusInputChange = (value: string) => {
        setBonusInputValue(value);
        setShowBonusDropdown(true);
        const numValue = Number(value.replace(/[^0-9.]/g, ''));
        if (value === '' || isNaN(numValue)) {
            setIsBonusValid(true);
            handleChange('bonusPercent', 0);
            return;
        }
        const isValid = bonusPercentOptions.includes(numValue);
        setIsBonusValid(isValid);
        if (isValid) {
            handleChange('bonusPercent', numValue);
        } else {
            handleChange('bonusPercent', numValue);
        }
    };

    const MAX_CARDS_PER_KIOSK_PER_TYPE = 5;

    // Validate card limit: max 5 cards per card type per kiosk
    const validateCardLimit = (cardType: string, venues: string[], currentOfferId?: number): { valid: boolean; message: string } => {
        for (const kiosk of venues) {
            // Count existing cards for this kiosk and card type
            const existingCount = offers.filter(offer => {
                // Skip the current offer being edited
                if (currentOfferId && offer.id === currentOfferId) return false;
                // Check if same card type and includes this kiosk
                return offer.cardType === cardType && offer.venue?.includes(kiosk);
            }).length;

            if (existingCount >= MAX_CARDS_PER_KIOSK_PER_TYPE) {
                return {
                    valid: false,
                    message: `You have reached the limit of ${MAX_CARDS_PER_KIOSK_PER_TYPE} ${cardType} cards for ${kiosk}. Please remove an existing card or choose a different kiosk/card type.`
                };
            }
        }
        return { valid: true, message: '' };
    };

    // Check for duplicate offer: same IDR + Tizo + Card Type in same kiosk
    const checkDuplicateOffer = (cost: number, tizoCredit: number, cardType: string, venues: string[], currentOfferId?: number): { valid: boolean; message: string } => {
        for (const kiosk of venues) {
            // Find existing offers with same IDR, Tizo, and card type in this kiosk
            const existingOffer = offers.find(offer => {
                // Skip the current offer being edited
                if (currentOfferId && offer.id === currentOfferId) return false;
                // Check if same IDR, same Tizo, same card type, and includes this kiosk
                return offer.cost === cost && offer.tizoCredit === tizoCredit && offer.cardType === cardType && offer.venue?.includes(kiosk);
            });

            if (existingOffer) {
                return {
                    valid: false,
                    message: `A ${cardType} card with IDR ${cost.toLocaleString()} and ${tizoCredit} Tizo already exists in ${kiosk} ("${existingOffer.productName}"). Please use a different IDR/Tizo value, card type, or kiosk.`
                };
            }
        }
        return { valid: true, message: '' };
    };

    const [formData, setFormData] = useState<PricingProduct>({
        productName: '',
        cost: 0,
        tizoCredit: 0,
        bonusPercent: 0,
        category: 'Voucher',
        cardType: '',
        venue: [],
        startDate: '',
        endDate: '',
        gift: 'Nil',
        giftDetails: '',
        topLeftIcon: '',
        topRightIcon: '',
        bottomLeftIcon: '',
        bottomRightIcon: ''
    });

    // Sync input values when editing an offer
    useEffect(() => {
        if (formData.cost > 0) {
            setCostInputValue(String(formData.cost));
            setIsCostValid(topUpValueOptions.includes(formData.cost));
        } else {
            setCostInputValue('');
            setIsCostValid(true);
        }
        if (formData.bonusPercent > 0) {
            setBonusInputValue(String(formData.bonusPercent));
            setIsBonusValid(bonusPercentOptions.includes(formData.bonusPercent));
        } else {
            setBonusInputValue('');
            setIsBonusValid(true);
        }
    }, [formData.cost, formData.bonusPercent, topUpValueOptions, bonusPercentOptions]);

    // Helper to select an offer and populate form
    const selectOffer = (index: number | null) => {
        setSelectedOfferIndex(index);
        if (index !== null && offers[index]) {
            setFormData(offers[index]);
        }
    };

    const computeTizoCredit = (costValue: number, bonusValue: number) => {
        if (!costValue || costValue <= 0) return 0;
        const baseTizo = costValue / 1000; // 1K IDR = 1 Tizo
        const multiplier = 1 + (bonusValue > 0 ? bonusValue / 100 : 0);
        return Number((baseTizo * multiplier).toFixed(2));
    };

    // Helper to update cost and auto-calculate tizoCredit
    const updateCostWithCalculation = (cost: number) => {
        const calculatedTizo = computeTizoCredit(cost, formData.bonusPercent);
        setFormData(prev => ({ ...prev, cost, tizoCredit: calculatedTizo }));
    };

    // Helper to update bonusPercent and auto-calculate tizoCredit
    const updateBonusWithCalculation = (bonusPercent: number) => {
        const calculatedTizo = computeTizoCredit(formData.cost, bonusPercent);
        setFormData(prev => ({ ...prev, bonusPercent, tizoCredit: calculatedTizo }));
    };

    const [rowActiveMap, setRowActiveMap] = useState<Record<number, boolean>>({});

    useEffect(() => {
        setRowActiveMap((prev) => {
            const next: Record<number, boolean> = {};
            offers.forEach((_, index) => {
                next[index] = prev[index] ?? true;
            });
            return next;
        });
    }, [offers]);

    // Capture preview card as image
    const capturePreviewCard = async (): Promise<string> => {
        if (!previewCardRef.current) return '';

        try {
            // Hide empty badge placeholders before capturing
            const emptyBadges = previewCardRef.current.querySelectorAll('.tizo-badge-default');
            emptyBadges.forEach((badge) => {
                (badge as HTMLElement).style.display = 'none';
            });

            const canvas = await html2canvas(previewCardRef.current, {
                backgroundColor: null,
                scale: 2,
                logging: false,
                useCORS: true,
                allowTaint: true,
                x: -160, // Capture area to the left for badges
                y: 0,
                width: (previewCardRef.current.offsetWidth + 320), // Add space for badges on both sides
                height: previewCardRef.current.offsetHeight,
            });

            // Restore empty badge placeholders after capturing
            emptyBadges.forEach((badge) => {
                (badge as HTMLElement).style.display = '';
            });

            return canvas.toDataURL('image/png');
        } catch (error) {
            console.error('Error capturing preview card:', error);
            return '';
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        // Validate Top Up Value (IDR)
        if (!isCostValid) {
            setLimitMessage('Please enter a valid Top Up Value (IDR) from the available options.');
            setShowLimitPopup(true);
            return;
        }

        // Validate Bonus Percent
        if (!isBonusValid) {
            setLimitMessage('Please enter a valid Bonus Percent from the available options.');
            setShowLimitPopup(true);
            return;
        }

        // Validate venue selection
        if (!formData.venue || formData.venue.length === 0) {
            setLimitMessage('Please select at least one kiosk/venue.');
            setShowLimitPopup(true);
            return;
        }

        // Validate Start Date
        if (!formData.startDate) {
            setLimitMessage('Please select a Start Date.');
            setShowLimitPopup(true);
            return;
        }

        // Validate End Date
        if (!formData.endDate) {
            setLimitMessage('Please select an End Date.');
            setShowLimitPopup(true);
            return;
        }

        // Validate for duplicate IDR + Tizo + Card Type in same kiosk
        const currentOfferId = selectedOfferIndex !== null ? offers[selectedOfferIndex]?.id : undefined;
        const duplicateCheck = checkDuplicateOffer(formData.cost, formData.tizoCredit, formData.cardType, formData.venue, currentOfferId);
        if (!duplicateCheck.valid) {
            setLimitMessage(duplicateCheck.message);
            setShowLimitPopup(true);
            return;
        }
        const validation = validateCardLimit(formData.cardType, formData.venue, currentOfferId);

        if (!validation.valid) {
            setLimitMessage(validation.message);
            setShowLimitPopup(true);
            return;
        }

        // Capture the preview card image
        const cardImage = await capturePreviewCard();
        const dataToSave = { ...formData, offerCardImage: cardImage };

        if (selectedOfferIndex !== null) {
            // Update existing offer
            await updateOffer(selectedOfferIndex, dataToSave);
        } else {
            // Add new offer
            await addOffer(dataToSave);
        }

        // Reset form
        handleReset();
    };

    const handleReset = () => {
        setFormData({
            productName: '',
            cost: 0,
            tizoCredit: 0,
            bonusPercent: 0,
            category: 'Voucher',
            cardType: '',
            venue: [],
            startDate: '',
            endDate: '',
            gift: 'Nil',
            giftDetails: '',
            topLeftIcon: '',
            topRightIcon: '',
            bottomLeftIcon: '',
            bottomRightIcon: '',
            offerCardImage: ''
        });
        selectOffer(null);
        setIsFormOpen(false);
    };

    const handleSort = (column: SortableColumn, direction?: 'asc' | 'desc') => {
        if (sortColumn === column) {
            if (direction && direction !== sortDirection) {
                setSortDirection(direction);
            } else if (!direction) {
                setSortDirection(prev => (prev === 'asc' ? 'desc' : 'asc'));
            }
            return;
        }

        setSortColumn(column);
        setSortDirection(direction ?? 'asc');
    };

    const handleImageUpload = (
        field: 'topLeftIcon' | 'topRightIcon' | 'bottomLeftIcon' | 'bottomRightIcon',
        file: File | null
    ) => {
        if (!file) {
            setFormData(prev => ({ ...prev, [field]: '' }));
            return;
        }

        const reader = new FileReader();
        reader.onloadend = () => {
            setFormData(prev => ({ ...prev, [field]: reader.result as string }));
        };
        reader.readAsDataURL(file);
    };

    const handleEdit = (index: number) => {
        selectOffer(index);
        setIsFormOpen(true);
    };

    const handleDelete = (index: number) => {
        if (window.confirm('Delete this offer?')) {
            deleteOffer(index);
            if (selectedOfferIndex === index) {
                handleReset();
            }
        }
    };

    const handleDownload = (index: number) => {
        const offer = offers[index];
        if (!offer) return;

        if (offer.offerCardImage) {
            // Download from stored image in database
            const link = document.createElement('a');
            link.href = offer.offerCardImage;
            link.download = `${offer.productName || 'offer-card'}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } else {
            // No image stored, show preview instead
            setPreviewOfferIndex(index);
            setIsPreviewOpen(true);
            alert('No card image saved. Please edit and save the offer first to generate a downloadable image.');
        }
    };

    const formatNumber = (num: number | undefined | null): string => {
        // Handle undefined, null, or empty values
        if (num === undefined || num === null || isNaN(Number(num))) {
            return '0';
        }

        const numValue = Number(num);

        if (numValue >= 1e33) {
            // Decillion
            return `${(numValue / 1e33).toFixed(numValue % 1e33 === 0 ? 0 : 1)}D`;
        } else if (numValue >= 1e30) {
            // Nonillion
            return `${(numValue / 1e30).toFixed(numValue % 1e30 === 0 ? 0 : 1)}N`;
        } else if (numValue >= 1e27) {
            // Octillion
            return `${(numValue / 1e27).toFixed(numValue % 1e27 === 0 ? 0 : 1)}Oc`;
        } else if (numValue >= 1e24) {
            // Septillion
            return `${(numValue / 1e24).toFixed(numValue % 1e24 === 0 ? 0 : 1)}Sp`;
        } else if (numValue >= 1e21) {
            // Sextillion
            return `${(numValue / 1e21).toFixed(numValue % 1e21 === 0 ? 0 : 1)}Sx`;
        } else if (numValue >= 1e18) {
            // Quintillion
            return `${(numValue / 1e18).toFixed(numValue % 1e18 === 0 ? 0 : 1)}Qa`;
        } else if (numValue >= 1e15) {
            // Quadrillion
            return `${(numValue / 1e15).toFixed(numValue % 1e15 === 0 ? 0 : 1)}Q`;
        } else if (numValue >= 1e12) {
            // Trillion
            return `${(numValue / 1e12).toFixed(numValue % 1e12 === 0 ? 0 : 1)}T`;
        } else if (numValue >= 1e9) {
            // Billion
            return `${(numValue / 1e9).toFixed(numValue % 1e9 === 0 ? 0 : 1)}B`;
        } else if (numValue >= 1e6) {
            // Million
            return `${(numValue / 1e6).toFixed(numValue % 1e6 === 0 ? 0 : 1)}M`;
        } else if (numValue >= 1000) {
            // Thousand
            return `${(numValue / 1000).toFixed(numValue % 1000 === 0 ? 0 : 1)}K`;
        }
        return numValue.toString();
    };

    const handleChange = (field: keyof PricingProduct, value: string | number) => {
        if (field === 'cost' && typeof value === 'number') {
            updateCostWithCalculation(value);
        } else if (field === 'bonusPercent' && typeof value === 'number') {
            updateBonusWithCalculation(value);
        } else {
            setFormData(prev => ({ ...prev, [field]: value }));
        }
    };

    const formatPrice = (price: number) => {
        if (isNaN(price)) return 'Rp 0';
        return `Rp ${Math.round(price).toLocaleString('en-US')}`;
    };

    const cardTypes = useMemo(() => (
        Array.from(new Set(offers.map(o => o.cardType).filter(Boolean))) as string[]
    ), [offers]);

    // Pre-compute original indices and ensure newest entries appear first
    const offersInDisplayOrder = useMemo(() => {
        return offers
            .map((offer, originalIndex) => ({ offer, originalIndex }))
            .reverse();
    }, [offers]);

    const filteredOffers = useMemo(() => {
        const term = tableSearchTerm.toLowerCase().trim();

        return offersInDisplayOrder.filter(({ offer, originalIndex }) => {
            let matchesType = true;
            const categoryUpper = (offer.category || '').toUpperCase();
            switch (filterType) {
                case 'OOH':
                    matchesType = categoryUpper.includes('OOH') || categoryUpper.includes('OFFER OF THE HOUR');
                    break;
                case 'OOD':
                    matchesType = categoryUpper.includes('OOD') || categoryUpper.includes('OFFER OF THE DAY');
                    break;
                case 'Voucher':
                    matchesType = categoryUpper.includes('VOUCHER');
                    break;
                default:
                    matchesType = true;
            }

            let matchesCard = true;
            if (cardFilter !== 'All') {
                matchesCard = (offer.cardType || '') === cardFilter;
            }

            let matchesActive = true;
            const isActive = rowActiveMap[originalIndex] ?? (offer.isActive !== false);
            if (activeFilter === 'active') {
                matchesActive = isActive;
            } else if (activeFilter === 'inactive') {
                matchesActive = !isActive;
            }

            if (!term) {
                return matchesType && matchesCard && matchesActive;
            }

            const matchesSearch =
                (offer.productName || '').toLowerCase().includes(term) ||
                (offer.category || '').toLowerCase().includes(term) ||
                (offer.cardType || '').toLowerCase().includes(term) ||
                String(offer.tizoCredit ?? '').includes(term) ||
                String(offer.cost ?? '').includes(term);

            return matchesType && matchesCard && matchesActive && matchesSearch;
        });
    }, [offersInDisplayOrder, filterType, cardFilter, activeFilter, tableSearchTerm, rowActiveMap]);

    // Apply sorting to filtered offers
    const sortedOffers = useMemo(() => {
        if (!sortColumn) return filteredOffers;

        const sorted = [...filteredOffers].sort((a, b) => {
            let aValue: string | number = a.offer[sortColumn] || '';
            let bValue: string | number = b.offer[sortColumn] || '';

            if (sortColumn === 'cost' || sortColumn === 'tizoCredit') {
                aValue = Number(aValue) || 0;
                bValue = Number(bValue) || 0;
            } else {
                aValue = String(aValue).toLowerCase();
                bValue = String(bValue).toLowerCase();
            }

            if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
            if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
            return 0;
        });

        return sorted;
    }, [filteredOffers, sortColumn, sortDirection]);

    // Render badge for saved offers - only show if image exists
    const renderBadgeForSaved = (
        position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right',
        icon?: string
    ) => {
        if (!icon) return null; // Don't render anything if no image
        return (
            <div className={`tizo-badge-container ${position}`}>
                <img src={icon} alt={`Badge ${position}`} className="tizo-badge-img" />
            </div>
        );
    };

    return (
        <div className="offer-builder-container">
            {/* Header */}
            <header className="builder-header">
                <h1 className="builder-title">
                    Timezone admin panel
                    <span style={{ fontSize: '0.6em', marginLeft: '10px', color: '#4ade80' }}>
                        🗄️ PostgreSQL
                    </span>
                </h1>
                <div className="header-actions">
                    {syncError && (
                        <span style={{ color: '#ef4444', marginRight: '10px', fontSize: '0.9em' }}>
                            ⚠️ {syncError}
                        </span>
                    )}
                    <button onClick={logout} className="logout-btn">Logout</button>
                </div>
            </header>

            {/* Main Layout */}
            <div className="main-layout">
                {/* Loading State */}
                {isLoading && (
                    <div style={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        height: '400px',
                        fontSize: '1.2em',
                        color: '#888'
                    }}>
                        Loading...
                    </div>
                )}

                {!isLoading && (
                    <>
                        <div className="offers-panel">
                            {/* Row 2: Filters & Actions */}
                            <div className="header-row row-2">
                                <div className="filter-group-left">
                                    <div className="filter-tabs-styled">
                                        <button
                                            className={`filter-tab ${filterType === 'All' ? 'active' : ''}`}
                                            onClick={() => setFilterType('All')}
                                        >
                                            All
                                        </button>
                                        <button
                                            className={`filter-tab ${filterType === 'OOH' ? 'active' : ''}`}
                                            onClick={() => setFilterType('OOH')}
                                        >
                                            OOH
                                        </button>
                                        <button
                                            className={`filter-tab ${filterType === 'OOD' ? 'active' : ''}`}
                                            onClick={() => setFilterType('OOD')}
                                        >
                                            OOD
                                        </button>
                                        <button
                                            className={`filter-tab ${filterType === 'Voucher' ? 'active' : ''}`}
                                            onClick={() => setFilterType('Voucher')}
                                        >
                                            Voucher
                                        </button>
                                    </div>
                                </div>

                                <div className="filter-group-right">
                                    <select
                                        className="offers-card-filter"
                                        value={cardFilter}
                                        onChange={(e) => setCardFilter(e.target.value)}
                                    >
                                        <option value="All">All cards</option>
                                        {cardTypes.map((type) => (
                                            <option key={type} value={type}>
                                                {type}
                                            </option>
                                        ))}
                                    </select>

                                    <div className="active-filter-tabs">
                                        <button
                                            type="button"
                                            className={activeFilter === 'all' ? 'active' : ''}
                                            onClick={() => setActiveFilter('all')}
                                        >
                                            All
                                        </button>
                                        <button
                                            type="button"
                                            className={activeFilter === 'active' ? 'active' : ''}
                                            onClick={() => setActiveFilter('active')}
                                        >
                                            Active
                                        </button>
                                        <button
                                            type="button"
                                            className={activeFilter === 'inactive' ? 'active' : ''}
                                            onClick={() => setActiveFilter('inactive')}
                                        >
                                            Inactive
                                        </button>
                                    </div>

                                    <div className="create-refresh-group">
                                        <button onClick={() => { setIsFormOpen(true); selectOffer(null); }} className="create-offer-btn">
                                            + Create New Offer
                                        </button>
                                        <button
                                            onClick={refreshFromDatabase}
                                            className="refresh-btn"
                                            disabled={isSyncing}
                                        >
                                            {isSyncing ? (
                                                <>
                                                    <FaSyncAlt className="refresh-icon spinning" />
                                                    Syncing...
                                                </>
                                            ) : (
                                                <>
                                                    <FaSyncAlt className="refresh-icon" />
                                                    Refresh
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            </div>

                            {/* Row 3: Search */}
                            <div className="header-row row-3">
                                <div className="offers-search">
                                    <span className="search-icon">🔍</span>
                                    <input
                                        type="text"
                                        className="offers-search-input"
                                        placeholder="Search..."
                                        value={tableSearchTerm}
                                        onChange={(e) => setTableSearchTerm(e.target.value)}
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="offers-table-container">
                            <table className="offers-table">
                                <thead>
                                    <tr>
                                        <th>Preview</th>
                                        <th>
                                            <div className="th-content">
                                                <span>Name</span>
                                                <div className="sort-arrows">
                                                    <button
                                                        className={`sort-arrow ${sortColumn === 'productName' && sortDirection === 'asc' ? 'active' : ''}`}
                                                        onClick={() => handleSort('productName', 'asc')}
                                                        title="Sort ascending"
                                                    >
                                                        ▲
                                                    </button>
                                                    <button
                                                        className={`sort-arrow ${sortColumn === 'productName' && sortDirection === 'desc' ? 'active' : ''}`}
                                                        onClick={() => handleSort('productName', 'desc')}
                                                        title="Sort descending"
                                                    >
                                                        ▼
                                                    </button>
                                                </div>
                                            </div>
                                        </th>
                                        <th>
                                            <div className="th-content">
                                                <span>Value</span>
                                                <div className="sort-arrows">
                                                    <button
                                                        className={`sort-arrow ${sortColumn === 'cost' && sortDirection === 'asc' ? 'active' : ''}`}
                                                        onClick={() => handleSort('cost', 'asc')}
                                                        title="Sort ascending"
                                                    >
                                                        ▲
                                                    </button>
                                                    <button
                                                        className={`sort-arrow ${sortColumn === 'cost' && sortDirection === 'desc' ? 'active' : ''}`}
                                                        onClick={() => handleSort('cost', 'desc')}
                                                        title="Sort descending"
                                                    >
                                                        ▼
                                                    </button>
                                                </div>
                                            </div>
                                        </th>
                                        <th>
                                            <div className="th-content">
                                                <span>Tizo</span>
                                                <div className="sort-arrows">
                                                    <button
                                                        className={`sort-arrow ${sortColumn === 'tizoCredit' && sortDirection === 'asc' ? 'active' : ''}`}
                                                        onClick={() => handleSort('tizoCredit', 'asc')}
                                                        title="Sort ascending"
                                                    >
                                                        ▲
                                                    </button>
                                                    <button
                                                        className={`sort-arrow ${sortColumn === 'tizoCredit' && sortDirection === 'desc' ? 'active' : ''}`}
                                                        onClick={() => handleSort('tizoCredit', 'desc')}
                                                        title="Sort descending"
                                                    >
                                                        ▼
                                                    </button>
                                                </div>
                                            </div>
                                        </th>
                                        <th>
                                            <div className="th-content">
                                                <span>Card type</span>
                                                <div className="sort-arrows">
                                                    <button
                                                        className={`sort-arrow ${sortColumn === 'cardType' && sortDirection === 'asc' ? 'active' : ''}`}
                                                        onClick={() => handleSort('cardType', 'asc')}
                                                        title="Sort ascending"
                                                    >
                                                        ▲
                                                    </button>
                                                    <button
                                                        className={`sort-arrow ${sortColumn === 'cardType' && sortDirection === 'desc' ? 'active' : ''}`}
                                                        onClick={() => handleSort('cardType', 'desc')}
                                                        title="Sort descending"
                                                    >
                                                        ▼
                                                    </button>
                                                </div>
                                            </div>
                                        </th>
                                        <th>Venue</th>
                                        <th>Active</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sortedOffers.map(({ offer, originalIndex }, index) => {
                                        const isActive = rowActiveMap[originalIndex] ?? (offer.isActive !== false);
                                        return (
                                            <tr key={`${offer.productName}-${originalIndex}-${index}`} className={selectedOfferIndex === originalIndex ? 'selected' : ''}>
                                                <td className="preview-cell">
                                                    <div
                                                        className="mini-preview-wrapper"
                                                        onClick={() => {
                                                            setPreviewOfferIndex(originalIndex);
                                                            setIsPreviewOpen(true);
                                                        }}
                                                        title="Click to preview"
                                                    >
                                                        {offer.offerCardImage ? (
                                                            <img
                                                                src={offer.offerCardImage}
                                                                alt={offer.productName}
                                                                className="saved-card-image"
                                                            />
                                                        ) : (
                                                            <div className="mini-preview-card-neon">
                                                                {renderBadgeForSaved('top-left', offer.topLeftIcon)}
                                                                {renderBadgeForSaved('top-right', offer.topRightIcon)}
                                                                {renderBadgeForSaved('bottom-left', offer.bottomLeftIcon)}
                                                                {renderBadgeForSaved('bottom-right', offer.bottomRightIcon)}

                                                                <div className="mini-neon-header">
                                                                    <div className="mini-price-display">
                                                                        <span className="mini-price-value">{formatNumber(offer.cost)}</span>
                                                                        <span className="mini-price-unit">RIBU</span>
                                                                    </div>
                                                                </div>

                                                                <div className="mini-neon-body">
                                                                    <div className="mini-get-label">DAPATKAN</div>
                                                                    <div className="mini-old-tizo-wrapper">
                                                                        <span className="mini-old-tizo-value">{formatNumber(Math.round(offer.tizoCredit / (1 + (offer.bonusPercent || 0) / 100)))}</span>
                                                                        <span className="mini-old-tizo-unit">TIZO</span>
                                                                    </div>

                                                                    <div className="mini-neon-footer">
                                                                        <div className="mini-tizo-value-big">
                                                                            <span className="mini-tizo-number">{formatNumber(offer.tizoCredit)}</span>
                                                                            <span className="mini-tizo-unit">TIZO</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        )}
                                                    </div>
                                                </td>
                                                <td>{offer.productName}</td>
                                                <td>{formatPrice(offer.cost)}</td>
                                                <td>{offer.tizoCredit}</td>
                                                <td>
                                                    <span className="card-type-badge">{offer.cardType}</span>
                                                </td>
                                                <td className="venue-cell">
                                                    {offer.venue && offer.venue.length > 0 ? (
                                                        <div className="venue-badges">
                                                            {offer.venue.map((v, i) => (
                                                                <span key={i} className="venue-badge">{v.replace('Kiosk ', 'K')}</span>
                                                            ))}
                                                        </div>
                                                    ) : (
                                                        <span className="no-venue">-</span>
                                                    )}
                                                </td>
                                                <td>
                                                    <label className="toggle-switch">
                                                        <input
                                                            type="checkbox"
                                                            checked={isActive}
                                                            onChange={async (e) => {
                                                                const checked = e.target.checked;
                                                                const offerId = offer.id;
                                                                if (offerId) {
                                                                    try {
                                                                        await ApiService.toggleOfferActive(offerId, checked);
                                                                        setRowActiveMap(prev => ({
                                                                            ...prev,
                                                                            [originalIndex]: checked
                                                                        }));
                                                                    } catch (error) {
                                                                        console.error('Failed to toggle offer status:', error);
                                                                        alert('Failed to update offer status. Please try again.');
                                                                    }
                                                                }
                                                            }}
                                                        />
                                                        <span className="toggle-slider"></span>
                                                    </label>
                                                </td>
                                                <td className="actions">
                                                    <button
                                                        onClick={() => handleDownload(originalIndex)}
                                                        className="download-icon"
                                                        title="Download Card"
                                                    >
                                                        <FaDownload />
                                                    </button>
                                                    <button
                                                        onClick={() => handleEdit(originalIndex)}
                                                        className="edit-icon"
                                                        title="Edit"
                                                    >
                                                        <FaEdit />
                                                    </button>
                                                    <button
                                                        onClick={() => handleDelete(originalIndex)}
                                                        className="delete-icon"
                                                        title="Delete"
                                                    >
                                                        <FaTrash />
                                                    </button>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>


                    </>
                )}
            </div>

            {/* Full-Screen Card Designer */}
            {
                isFormOpen && (
                    <div className="card-designer-fullscreen">
                        {/* Designer Header */}
                        <div className="designer-header">
                            <div className="designer-header-left">
                                <h2 className="designer-title">
                                    {selectedOfferIndex !== null ? 'Edit Offer Card' : 'Design New Offer Card'}
                                </h2>
                            </div>
                            <div className="designer-header-right">
                                <button type="button" onClick={handleReset} className="designer-cancel-btn">
                                    Cancel
                                </button>
                                <button type="submit" form="offer-form" className="designer-save-btn">
                                    {selectedOfferIndex !== null ? 'Update Card' : 'Save Card'}
                                </button>
                            </div>
                        </div>

                        <div className="designer-content">
                            {/* Left Panel - Form Controls */}
                            <div className="designer-sidebar">
                                <div className="sidebar-section">
                                    <h3 className="sidebar-section-title">Card Details</h3>
                                    <form id="offer-form" onSubmit={handleSubmit} className="designer-form">
                                        <div className="form-group">
                                            <label>Product Name</label>
                                            <input
                                                type="text"
                                                value={formData.productName}
                                                onChange={(e) => handleChange('productName', e.target.value)}
                                                placeholder="Fun 100K Get 110 Tz"
                                                required
                                            />
                                        </div>

                                        <div className="form-group">
                                            <label>Type of Deal</label>
                                            <select
                                                value={formData.category}
                                                onChange={(e) => handleChange('category', e.target.value)}
                                                required
                                            >
                                                <option value="Voucher">Voucher</option>
                                                <option value="OFFER OF THE DAY">OFFER OF THE DAY</option>
                                                <option value="OFFER OF THE HOUR">OFFER OF THE HOUR</option>
                                                <option value="Seasonal">Seasonal</option>
                                                <option value="Scratch Card">Scratch Card</option>
                                            </select>
                                        </div>

                                        <div className="form-group">
                                            <label>Card Type</label>
                                            <select
                                                value={formData.cardType}
                                                onChange={(e) => handleChange('cardType', e.target.value)}
                                                required
                                            >
                                                <option value="" disabled>Select Card Type</option>
                                                {formData.category === 'Scratch Card' ? (
                                                    <>
                                                        <option value="New User">New User</option>
                                                        <option value="Existing User">Existing User</option>
                                                    </>
                                                ) : (
                                                    <>
                                                        <option value="New User">New User</option>
                                                        <option value="Red">Red</option>
                                                        <option value="Blue">Blue</option>
                                                        <option value="Gold">Gold</option>
                                                        <option value="Platinum">Platinum</option>
                                                    </>
                                                )}
                                            </select>
                                        </div>

                                        <div className="form-group">
                                            <label>Top Up Value (IDR)</label>
                                            <div className="combo-box" ref={costDropdownRef}>
                                                <div className="combo-input-wrapper">
                                                    <input
                                                        type="text"
                                                        value={costInputValue}
                                                        onChange={(e) => handleCostInputChange(e.target.value)}
                                                        onFocus={() => setShowCostDropdown(true)}
                                                        placeholder="Type or select value"
                                                        className={!isCostValid ? 'input-error' : ''}
                                                    />
                                                    <button
                                                        type="button"
                                                        className="combo-dropdown-btn"
                                                        onClick={() => setShowCostDropdown(!showCostDropdown)}
                                                    >
                                                        ▼
                                                    </button>
                                                </div>
                                                {showCostDropdown && (
                                                    <div className="combo-dropdown-list">
                                                        {filteredTopUpOptions.length > 0 ? (
                                                            filteredTopUpOptions.map(idrValue => (
                                                                <div
                                                                    key={idrValue}
                                                                    className={`combo-dropdown-item ${formData.cost === idrValue ? 'selected' : ''}`}
                                                                    onClick={() => {
                                                                        setCostInputValue(String(idrValue));
                                                                        handleChange('cost', idrValue);
                                                                        setIsCostValid(true);
                                                                        setShowCostDropdown(false);
                                                                    }}
                                                                >
                                                                    <span className="combo-item-value">{idrValue}</span>
                                                                    <span className="combo-item-label">{formatPrice(idrValue)}</span>
                                                                </div>
                                                            ))
                                                        ) : (
                                                            <div className="combo-dropdown-empty">No matching values</div>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                            {!isCostValid && (
                                                <span className="input-error-message">Enter a valid IDR value</span>
                                            )}
                                        </div>

                                        <div className="form-group">
                                            <label>% bonus Tizo</label>
                                            <div className="combo-box" ref={bonusDropdownRef}>
                                                <div className="combo-input-wrapper">
                                                    <input
                                                        type="text"
                                                        value={bonusInputValue}
                                                        onChange={(e) => handleBonusInputChange(e.target.value)}
                                                        onFocus={() => setShowBonusDropdown(true)}
                                                        placeholder="Type or select %"
                                                        className={!isBonusValid ? 'input-error' : ''}
                                                    />
                                                    <button
                                                        type="button"
                                                        className="combo-dropdown-btn"
                                                        onClick={() => setShowBonusDropdown(!showBonusDropdown)}
                                                    >
                                                        ▼
                                                    </button>
                                                </div>
                                                {showBonusDropdown && (
                                                    <div className="combo-dropdown-list">
                                                        {filteredBonusOptions.length > 0 ? (
                                                            filteredBonusOptions.map(percent => (
                                                                <div
                                                                    key={percent}
                                                                    className={`combo-dropdown-item ${formData.bonusPercent === percent ? 'selected' : ''}`}
                                                                    onClick={() => {
                                                                        setBonusInputValue(String(percent));
                                                                        handleChange('bonusPercent', percent);
                                                                        setIsBonusValid(true);
                                                                        setShowBonusDropdown(false);
                                                                    }}
                                                                >
                                                                    <span className="combo-item-value">{percent}%</span>
                                                                </div>
                                                            ))
                                                        ) : (
                                                            <div className="combo-dropdown-empty">No matching values</div>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                            {!isBonusValid && (
                                                <span className="input-error-message">Enter a valid bonus %</span>
                                            )}
                                        </div>
                                        <div className="form-group">
                                            <label>Total Tizo Value</label>
                                            <input
                                                type="text"
                                                value={formData.tizoCredit === 0 ? '' : formData.tizoCredit}
                                                onChange={(e) => handleChange('tizoCredit', Number(e.target.value) || 0)}
                                                placeholder="Auto-calculated or enter value"
                                            />
                                        </div>

                                        <div className="form-group">
                                            <label>Gift</label>
                                            <select
                                                value={(formData.category === 'Voucher' && formData.cardType !== 'New User') ? 'Nil' : (formData.gift || 'Nil')}
                                                onChange={(e) => {
                                                    handleChange('gift', e.target.value);
                                                    // Reset gift details when gift type changes
                                                    if (e.target.value === 'Nil') {
                                                        handleChange('giftDetails', '');
                                                    }
                                                }}
                                                disabled={formData.category === 'Voucher' && formData.cardType !== 'New User'}
                                            >
                                                <option value="Nil">Nil</option>
                                                <option value="Free Gift">Free Gift</option>
                                                <option value="Free Games">Free Games</option>
                                                <option value="Free Etickets">Free Etickets</option>
                                            </select>
                                        </div>

                                        <div className="form-group">
                                            <label>Gift Details</label>
                                            {formData.gift === 'Nil' || !formData.gift ? (
                                                <input
                                                    type="text"
                                                    value="NIL"
                                                    disabled
                                                    className="gift-details-disabled"
                                                />
                                            ) : formData.gift === 'Free Gift' ? (
                                                <input
                                                    type="text"
                                                    value={formData.giftDetails || ''}
                                                    onChange={(e) => handleChange('giftDetails', e.target.value)}
                                                    placeholder="Enter gift description"
                                                />
                                            ) : (
                                                <input
                                                    type="number"
                                                    value={formData.giftDetails || ''}
                                                    onChange={(e) => handleChange('giftDetails', e.target.value)}
                                                    placeholder={formData.gift === 'Free Games' ? 'Number of games' : 'Number of etickets'}
                                                    min="0"
                                                />
                                            )}
                                        </div>

                                        <div className="form-group">
                                            <label>Start Date</label>
                                            <input
                                                type="date"
                                                value={formData.startDate ? (() => {
                                                    const d = new Date(formData.startDate);
                                                    if (isNaN(d.getTime())) return '';
                                                    const year = d.getFullYear();
                                                    const month = String(d.getMonth() + 1).padStart(2, '0');
                                                    const day = String(d.getDate()).padStart(2, '0');
                                                    return `${year}-${month}-${day}`;
                                                })() : ''}
                                                onChange={(e) => handleChange('startDate', e.target.value)}
                                                min={selectedOfferIndex === null ? new Date().toLocaleDateString('en-CA') : undefined}
                                            />
                                        </div>

                                        <div className="form-group">
                                            <label>End Date</label>
                                            <input
                                                type="date"
                                                value={formData.endDate ? (() => {
                                                    const d = new Date(formData.endDate);
                                                    if (isNaN(d.getTime())) return '';
                                                    const year = d.getFullYear();
                                                    const month = String(d.getMonth() + 1).padStart(2, '0');
                                                    const day = String(d.getDate()).padStart(2, '0');
                                                    return `${year}-${month}-${day}`;
                                                })() : ''}
                                                onChange={(e) => handleChange('endDate', e.target.value)}
                                                min={formData.startDate ? (() => {
                                                    const d = new Date(formData.startDate);
                                                    if (isNaN(d.getTime())) return new Date().toLocaleDateString('en-CA');
                                                    const year = d.getFullYear();
                                                    const month = String(d.getMonth() + 1).padStart(2, '0');
                                                    const day = String(d.getDate()).padStart(2, '0');
                                                    return `${year}-${month}-${day}`;
                                                })() : new Date().toLocaleDateString('en-CA')}
                                            />
                                        </div>

                                        <div className="form-group">
                                            <label>Venue</label>
                                            <div className="venue-checkboxes">
                                                <label className="checkbox-label">
                                                    <input
                                                        type="checkbox"
                                                        checked={(formData.venue?.length || 0) === 5}
                                                        onChange={(e) => {
                                                            if (e.target.checked) {
                                                                setFormData(prev => ({
                                                                    ...prev,
                                                                    venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
                                                                }));
                                                            } else {
                                                                setFormData(prev => ({ ...prev, venue: [] }));
                                                            }
                                                        }}
                                                    />
                                                    <span>ALL</span>
                                                </label>
                                                {['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5'].map(kiosk => (
                                                    <label key={kiosk} className="checkbox-label">
                                                        <input
                                                            type="checkbox"
                                                            checked={formData.venue?.includes(kiosk) || false}
                                                            onChange={(e) => {
                                                                if (e.target.checked) {
                                                                    setFormData(prev => ({
                                                                        ...prev,
                                                                        venue: [...(prev.venue || []), kiosk]
                                                                    }));
                                                                } else {
                                                                    setFormData(prev => ({
                                                                        ...prev,
                                                                        venue: (prev.venue || []).filter(v => v !== kiosk)
                                                                    }));
                                                                }
                                                            }}
                                                        />
                                                        <span>{kiosk}</span>
                                                    </label>
                                                ))}
                                            </div>
                                        </div>


                                    </form>
                                </div>

                                {/* Card Template Selection */}
                                <div className="sidebar-section">
                                    <h3 className="sidebar-section-title">Card Color</h3>
                                    <div className="template-selector">
                                        {(showAllTemplates ? CARD_TEMPLATES : CARD_TEMPLATES.slice(0, INITIAL_TEMPLATES_COUNT)).map((template) => (
                                            <div
                                                key={template.id}
                                                className={`template-option ${selectedTemplate === template.id ? 'selected' : ''}`}
                                                onClick={() => setSelectedTemplate(template.id)}
                                            >
                                                <img src={template.image} alt={template.name} className="template-thumbnail" />
                                                <span className="template-name">{template.name}</span>
                                            </div>
                                        ))}
                                    </div>
                                    {CARD_TEMPLATES.length > INITIAL_TEMPLATES_COUNT && (
                                        <button
                                            type="button"
                                            className="see-more-btn"
                                            onClick={() => setShowAllTemplates(!showAllTemplates)}
                                        >
                                            {showAllTemplates ? 'Show Less' : `See More (${CARD_TEMPLATES.length - INITIAL_TEMPLATES_COUNT} more)`}
                                        </button>
                                    )}
                                </div>

                                {/* Image Upload Section */}
                                <div className="sidebar-section">
                                    <h3 className="sidebar-section-title">Card Icons</h3>
                                    <div className="icon-upload-grid">
                                        {/* Character Icon Upload */}
                                        <div className="icon-upload-item">
                                            <label>Top Left Icon</label>
                                            <div className="icon-upload-box">
                                                {formData.topLeftIcon ? (
                                                    <div className="icon-preview-wrapper">
                                                        <img src={formData.topLeftIcon} alt="Character" className="icon-preview" />
                                                        <button type="button" className="icon-remove-btn" onClick={() => handleImageUpload('topLeftIcon', null)}>✕</button>
                                                    </div>
                                                ) : (
                                                    <label className="icon-upload-label">
                                                        <input type="file" accept="image/*" onChange={(e) => { const file = e.target.files?.[0]; if (file) handleImageUpload('topLeftIcon', file); }} className="file-input" />
                                                        <span className="icon-upload-placeholder">+ Add</span>
                                                    </label>
                                                )}
                                            </div>
                                        </div>

                                        {/* Celebration Icon Upload */}
                                        <div className="icon-upload-item">
                                            <label>Top Right Icon</label>
                                            <div className="icon-upload-box">
                                                {formData.topRightIcon ? (
                                                    <div className="icon-preview-wrapper">
                                                        <img src={formData.topRightIcon} alt="Celebration" className="icon-preview" />
                                                        <button type="button" className="icon-remove-btn" onClick={() => handleImageUpload('topRightIcon', null)}>✕</button>
                                                    </div>
                                                ) : (
                                                    <label className="icon-upload-label">
                                                        <input type="file" accept="image/*" onChange={(e) => { const file = e.target.files?.[0]; if (file) handleImageUpload('topRightIcon', file); }} className="file-input" />
                                                        <span className="icon-upload-placeholder">+ Add</span>
                                                    </label>
                                                )}
                                            </div>
                                        </div>

                                        {/* Bottom Left Icon Upload */}
                                        <div className="icon-upload-item">
                                            <label>Bottom Left Icon</label>
                                            <div className="icon-upload-box">
                                                {formData.bottomLeftIcon ? (
                                                    <div className="icon-preview-wrapper">
                                                        <img src={formData.bottomLeftIcon} alt="Bottom Left" className="icon-preview" />
                                                        <button type="button" className="icon-remove-btn" onClick={() => handleImageUpload('bottomLeftIcon', null)}>✕</button>
                                                    </div>
                                                ) : (
                                                    <label className="icon-upload-label">
                                                        <input type="file" accept="image/*" onChange={(e) => { const file = e.target.files?.[0]; if (file) handleImageUpload('bottomLeftIcon', file); }} className="file-input" />
                                                        <span className="icon-upload-placeholder">+ Add</span>
                                                    </label>
                                                )}
                                            </div>
                                        </div>

                                        {/* Bottom Right Icon Upload */}
                                        <div className="icon-upload-item">
                                            <label>Bottom Right Icon</label>
                                            <div className="icon-upload-box">
                                                {formData.bottomRightIcon ? (
                                                    <div className="icon-preview-wrapper">
                                                        <img src={formData.bottomRightIcon} alt="Bottom Right" className="icon-preview" />
                                                        <button type="button" className="icon-remove-btn" onClick={() => handleImageUpload('bottomRightIcon', null)}>✕</button>
                                                    </div>
                                                ) : (
                                                    <label className="icon-upload-label">
                                                        <input type="file" accept="image/*" onChange={(e) => { const file = e.target.files?.[0]; if (file) handleImageUpload('bottomRightIcon', file); }} className="file-input" />
                                                        <span className="icon-upload-placeholder">+ Add</span>
                                                    </label>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Center - Live Card Preview */}
                            <div className="designer-canvas">
                                <div className="canvas-container">
                                    <div className="canvas-label">Live Preview</div>
                                    <div
                                        className="preview-card-neon"
                                        ref={previewCardRef}
                                        style={{ backgroundImage: `url(${CARD_TEMPLATES.find(t => t.id === selectedTemplate)?.image || cardTemplate1})` }}
                                    >
                                        {/* Badge containers - only show if icon exists */}
                                        {/* Top Left Badge */}
                                        <div className="tizo-badge-container top-left">
                                            {formData.topLeftIcon ? (
                                                <img src={formData.topLeftIcon} alt="Character" className="tizo-badge-img" />
                                            ) : (
                                                <div className="tizo-badge-default"></div>
                                            )}
                                        </div>

                                        {/* Top Right Badge */}
                                        <div className="tizo-badge-container top-right">
                                            {formData.topRightIcon ? (
                                                <img src={formData.topRightIcon} alt="Celebration" className="tizo-badge-img" />
                                            ) : (
                                                <div className="tizo-badge-default"></div>
                                            )}
                                        </div>

                                        {/* Bottom Left Badge */}
                                        <div className="tizo-badge-container bottom-left">
                                            {formData.bottomLeftIcon ? (
                                                <img src={formData.bottomLeftIcon} alt="Bottom Left" className="tizo-badge-img" />
                                            ) : (
                                                <div className="tizo-badge-default"></div>
                                            )}
                                        </div>

                                        {/* Bottom Right Badge */}
                                        <div className="tizo-badge-container bottom-right">
                                            {formData.bottomRightIcon ? (
                                                <img src={formData.bottomRightIcon} alt="Bottom Right" className="tizo-badge-img" />
                                            ) : (
                                                <div className="tizo-badge-default"></div>
                                            )}
                                        </div>

                                        {/* Top Section: Price - always show header, value appears when cost > 0 */}
                                        <div className="neon-header">
                                            {formData.cost > 0 && (
                                                <div className="price-display">
                                                    <span className="price-value">{Math.round(formData.cost / 1000)}</span>
                                                    <span className="price-unit">RIBU</span>
                                                </div>
                                            )}
                                        </div>

                                        {/* Middle Section - only show if tizoCredit > 0 */}
                                        {formData.tizoCredit > 0 && (
                                            <div className="neon-body">
                                                <div className="get-label">DAPATKAN</div>
                                                <div className="old-tizo-wrapper">
                                                    <span className="old-tizo-value">
                                                        {Math.round(formData.cost / 1000)}
                                                    </span>
                                                    <span className="old-tizo-unit">TIZO</span>
                                                </div>

                                                {/* Bottom Section: Tizo Value */}
                                                <div className="neon-footer">
                                                    <div className="tizo-value-big">
                                                        <span className={`tizo-number ${formData.tizoCredit >= 1000000 ? 'tizo-number-small' : formData.tizoCredit >= 10000 ? 'tizo-number-medium' : ''}`}>{formData.tizoCredit}</span>
                                                        <span className="tizo-unit">TIZO</span>
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div >
                )
            }

            {/* Preview Popup Modal */}
            {
                isPreviewOpen && previewOfferIndex !== null && offers[previewOfferIndex] && (
                    <div className="preview-overlay" onClick={() => setIsPreviewOpen(false)}>
                        <div className="preview-modal" onClick={(e) => e.stopPropagation()}>
                            <button className="close-preview-btn" onClick={() => setIsPreviewOpen(false)}>✕</button>
                            {offers[previewOfferIndex].offerCardImage ? (
                                <img
                                    src={offers[previewOfferIndex].offerCardImage}
                                    alt={offers[previewOfferIndex].productName}
                                    className="preview-modal-image"
                                />
                            ) : (
                                <div className="preview-card-neon">
                                    {renderBadgeForSaved('top-left', offers[previewOfferIndex].topLeftIcon)}
                                    {renderBadgeForSaved('top-right', offers[previewOfferIndex].topRightIcon)}
                                    {renderBadgeForSaved('bottom-left', offers[previewOfferIndex].bottomLeftIcon)}
                                    {renderBadgeForSaved('bottom-right', offers[previewOfferIndex].bottomRightIcon)}

                                    {/* Top Section: Price */}
                                    <div className="neon-header">
                                        <div className="price-display">
                                            <span className="price-value">{formatNumber(offers[previewOfferIndex].cost)}</span>
                                            <span className="price-unit">RIBU</span>
                                        </div>
                                    </div>

                                    {/* Middle Section: DAPATKAN */}
                                    <div className="neon-body">
                                        <div className="get-label">DAPATKAN</div>
                                        <div className="old-tizo-wrapper">
                                            <span className="old-tizo-value">{formatNumber(Math.round(offers[previewOfferIndex].tizoCredit / (1 + (offers[previewOfferIndex].bonusPercent || 0) / 100)))}</span>
                                            <span className="old-tizo-unit">TIZO</span>
                                        </div>

                                        {/* Bottom Section: Tizo Value */}
                                        <div className="neon-footer">
                                            <div className="tizo-value-big">
                                                <span className="tizo-number">{formatNumber(offers[previewOfferIndex].tizoCredit)}</span>
                                                <span className="tizo-unit">TIZO</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                )
            }

            {/* Card Limit Warning Popup */}
            {
                showLimitPopup && (
                    <div className="limit-popup-overlay" onClick={() => setShowLimitPopup(false)}>
                        <div className="limit-popup-modal" onClick={(e) => e.stopPropagation()}>
                            <div className="limit-popup-icon">⚠️</div>
                            <h3 className="limit-popup-title">Card Limit Reached</h3>
                            <p className="limit-popup-message">{limitMessage}</p>
                            <button
                                className="limit-popup-btn"
                                onClick={() => setShowLimitPopup(false)}
                            >
                                OK
                            </button>
                        </div>
                    </div>
                )
            }
        </div >
    );
};
