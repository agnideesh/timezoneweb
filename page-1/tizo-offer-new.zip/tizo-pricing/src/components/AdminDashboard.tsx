import { useState } from 'react';
import type { PricingProduct } from '../types';
import { FaEdit, FaTrash, FaPlus, FaSignOutAlt, FaUndo } from 'react-icons/fa';
import { OfferModal } from './OfferModal';
import { useOffers } from '../hooks/useOffers';
import { useAuth } from '../hooks/useAuth';
import './AdminDashboard.css';

export const AdminDashboard = () => {
    const { offers, addOffer, updateOffer, deleteOffer, resetToDefault } = useOffers();
    const { username, logout } = useAuth();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingIndex, setEditingIndex] = useState<number | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('All');

    const handleEdit = (index: number) => {
        setEditingIndex(index);
        setIsModalOpen(true);
    };

    const handleDelete = (index: number) => {
        if (window.confirm('Are you sure you want to delete this offer?')) {
            deleteOffer(index);
        }
    };

    const handleAddNew = () => {
        setEditingIndex(null);
        setIsModalOpen(true);
    };

    const handleSave = (offer: PricingProduct) => {
        if (editingIndex !== null) {
            updateOffer(editingIndex, offer);
        } else {
            addOffer(offer);
        }
        setIsModalOpen(false);
        setEditingIndex(null);
    };

    const handleReset = () => {
        if (window.confirm('Reset all offers to default? This will delete any custom offers you\'ve added.')) {
            resetToDefault();
        }
    };

    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(price);
    };

    // Filter offers
    const filteredOffers = offers.filter(offer => {
        const matchesSearch = offer.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            offer.category.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = categoryFilter === 'All' || offer.category === categoryFilter;
        return matchesSearch && matchesCategory;
    });

    const categories = ['All', ...Array.from(new Set(offers.map(o => o.category)))];

    return (
        <div className="admin-dashboard">
            <header className="dashboard-header">
                <div className="header-content">
                    <div>
                        <h1 className="dashboard-title">
                            <span className="gradient-text">Tizo Credit</span> Admin Dashboard
                        </h1>
                        <p className="dashboard-subtitle">Welcome, {username}!</p>
                    </div>
                    <button onClick={logout} className="logout-button">
                        <FaSignOutAlt /> Logout
                    </button>
                </div>
            </header>

            <main className="dashboard-main">
                <div className="dashboard-controls">
                    <div className="search-filter-group">
                        <input
                            type="text"
                            placeholder="Search offers..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="search-input"
                        />

                        <select
                            value={categoryFilter}
                            onChange={(e) => setCategoryFilter(e.target.value)}
                            className="category-select"
                        >
                            {categories.map(cat => (
                                <option key={cat} value={cat}>{cat}</option>
                            ))}
                        </select>
                    </div>

                    <div className="action-buttons">
                        <button onClick={handleReset} className="reset-button">
                            <FaUndo /> Reset to Default
                        </button>
                        <button onClick={handleAddNew} className="add-button">
                            <FaPlus /> Add New Offer
                        </button>
                    </div>
                </div>

                <div className="stats-grid">
                    <div className="stat-card">
                        <div className="stat-icon">📦</div>
                        <div className="stat-info">
                            <div className="stat-value">{offers.length}</div>
                            <div className="stat-label">Total Offers</div>
                        </div>
                    </div>
                    <div className="stat-card">
                        <div className="stat-icon">🔥</div>
                        <div className="stat-info">
                            <div className="stat-value">{offers.filter(o => o.bonusPercent >= 80).length}</div>
                            <div className="stat-label">Hot Deals</div>
                        </div>
                    </div>
                    <div className="stat-card">
                        <div className="stat-icon">🎯</div>
                        <div className="stat-info">
                            <div className="stat-value">{categories.length - 1}</div>
                            <div className="stat-label">Categories</div>
                        </div>
                    </div>
                </div>

                <div className="table-container">
                    <table className="offers-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Product Name</th>
                                <th>Cost (IDR)</th>
                                <th>Tizo Credit</th>
                                <th>Bonus %</th>
                                <th>Category</th>
                                <th>Remarks</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredOffers.map((offer, index) => {
                                const originalIndex = offers.indexOf(offer);
                                return (
                                    <tr key={index}>
                                        <td>{index + 1}</td>
                                        <td className="product-name-cell">{offer.productName}</td>
                                        <td className="price-cell">{formatPrice(offer.cost)}</td>
                                        <td className="credit-cell">{offer.tizoCredit}</td>
                                        <td>
                                            <span className={`bonus-badge ${offer.bonusPercent >= 80 ? 'hot' : ''}`}>
                                                {offer.bonusPercent}%
                                            </span>
                                        </td>
                                        <td>
                                            <span className="category-tag">{offer.category}</span>
                                        </td>
                                        <td className="remarks-cell">{offer.remarks || '-'}</td>
                                        <td className="actions-cell">
                                            <button
                                                onClick={() => handleEdit(originalIndex)}
                                                className="edit-btn"
                                                title="Edit"
                                            >
                                                <FaEdit />
                                            </button>
                                            <button
                                                onClick={() => handleDelete(originalIndex)}
                                                className="delete-btn"
                                                title="Delete"
                                            >
                                                <FaTrash />
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>

                    {filteredOffers.length === 0 && (
                        <div className="no-results">
                            <p>No offers found</p>
                        </div>
                    )}
                </div>
            </main>

            {isModalOpen && (
                <OfferModal
                    offer={editingIndex !== null ? offers[editingIndex] : undefined}
                    onSave={handleSave}
                    onClose={() => {
                        setIsModalOpen(false);
                        setEditingIndex(null);
                    }}
                />
            )}
        </div>
    );
};
