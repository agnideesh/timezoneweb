/**
 * API Configuration for Google Sheets Integration
 * 
 * IMPORTANT: Replace the URL below with your Google Apps Script Web App URL
 * 
 * To get your URL:
 * 1. Follow the setup guide in GOOGLE_SHEETS_SETUP.md
 * 2. Deploy your Apps Script as a Web App
 * 3. Copy the deployment URL
 * 4. Paste it below
 */

export const GOOGLE_SHEETS_API_URL = 'https://script.google.com/macros/s/AKfycbz3F8rIdoXPDtXiYeS6kcgfn5X0j8IHHC1W_dW8Kvl4k8x1RySte2-Er50DhdvpnU1e/exec';

// Example URL format:
// 'https://script.google.com/macros/s/AKfycby.../exec'
