import { useState, useEffect } from 'react';
import type { PricingProduct } from '../types';
import { pricingData as initialData } from '../data/pricingData';
import ApiService from '../services/apiService';

const STORAGE_KEY = 'tizo_offers';

// Helper function to safely save to localStorage with quota handling
const safeLocalStorageSet = (key: string, data: unknown): boolean => {
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
    } catch (error) {
        if (error instanceof DOMException &&
            (error.name === 'QuotaExceededError' || error.code === 22)) {
            console.warn('⚠️ localStorage quota exceeded. Clearing cache...');
            // Clear the cache to free up space
            localStorage.removeItem(key);
            // Optionally try once more with fresh storage
            try {
                localStorage.setItem(key, JSON.stringify(data));
                return true;
            } catch {
                console.warn('⚠️ Still cannot save to localStorage. Proceeding without cache.');
                return false;
            }
        }
        console.error('❌ Error saving to localStorage:', error);
        return false;
    }
};

export const useOffers = () => {
    const [offers, setOffers] = useState<PricingProduct[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSyncing, setIsSyncing] = useState(false);
    const [syncError, setSyncError] = useState<string | null>(null);

    // Load offers from PostgreSQL database
    useEffect(() => {
        const loadOffers = async () => {
            setIsLoading(true);
            setSyncError(null);

            try {
                // Fetch from PostgreSQL database
                const dbData = await ApiService.fetchOffers();
                setOffers(dbData);
                // Also save to localStorage as cache
                safeLocalStorageSet(STORAGE_KEY, dbData);
                console.log('✅ Loaded offers from database');
            } catch (error) {
                console.warn('⚠️ Failed to load from database, using localStorage:', error);
                setSyncError('Failed to connect to database. Using local data.');
                // Fallback to localStorage
                loadFromLocalStorage();
            }

            setIsLoading(false);
        };

        loadOffers();
    }, []);

    // Load from localStorage
    const loadFromLocalStorage = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
            try {
                setOffers(JSON.parse(stored));
            } catch (error) {
                console.error('Error loading offers from localStorage:', error);
                setOffers(initialData);
                safeLocalStorageSet(STORAGE_KEY, initialData);
            }
        } else {
            setOffers(initialData);
            safeLocalStorageSet(STORAGE_KEY, initialData);
        }
    };

    // Add offer to database
    const addOffer = async (offer: PricingProduct) => {
        setIsSyncing(true);
        setSyncError(null);
        try {
            await ApiService.addOffer(offer);
            // Refresh from database to get the new ID
            const dbData = await ApiService.fetchOffers();
            setOffers(dbData);
            safeLocalStorageSet(STORAGE_KEY, dbData);
            console.log('✅ Offer added to database');
        } catch (error) {
            console.error('❌ Failed to add offer:', error);
            setSyncError('Failed to add offer to database.');
            // Add locally as fallback
            const newOffers = [...offers, offer];
            setOffers(newOffers);
            safeLocalStorageSet(STORAGE_KEY, newOffers);
        } finally {
            setIsSyncing(false);
        }
    };

    const updateOffer = async (index: number, updatedOffer: PricingProduct) => {
        setIsSyncing(true);
        setSyncError(null);
        try {
            const offerId = offers[index].id;
            if (offerId) {
                await ApiService.updateOffer(offerId, updatedOffer);
                // Refresh from database
                const dbData = await ApiService.fetchOffers();
                setOffers(dbData);
                safeLocalStorageSet(STORAGE_KEY, dbData);
                console.log('✅ Offer updated in database');
            }
        } catch (error) {
            console.error('❌ Failed to update offer:', error);
            setSyncError('Failed to update offer in database.');
            // Update locally as fallback
            const newOffers = [...offers];
            newOffers[index] = updatedOffer;
            setOffers(newOffers);
            safeLocalStorageSet(STORAGE_KEY, newOffers);
        } finally {
            setIsSyncing(false);
        }
    };

    const deleteOffer = async (index: number) => {
        setIsSyncing(true);
        setSyncError(null);
        try {
            const offerId = offers[index].id;
            if (offerId) {
                await ApiService.deleteOffer(offerId);
                // Refresh from database
                const dbData = await ApiService.fetchOffers();
                setOffers(dbData);
                safeLocalStorageSet(STORAGE_KEY, dbData);
                console.log('✅ Offer deleted from database');
            }
        } catch (error) {
            console.error('❌ Failed to delete offer:', error);
            setSyncError('Failed to delete offer from database.');
            // Delete locally as fallback
            const newOffers = offers.filter((_, i) => i !== index);
            setOffers(newOffers);
            safeLocalStorageSet(STORAGE_KEY, newOffers);
        } finally {
            setIsSyncing(false);
        }
    };

    const resetToDefault = async () => {
        setIsSyncing(true);
        setSyncError(null);
        try {
            await ApiService.bulkUpdateOffers(initialData);
            setOffers(initialData);
            safeLocalStorageSet(STORAGE_KEY, initialData);
            console.log('✅ Reset to default data');
        } catch (error) {
            console.error('❌ Failed to reset:', error);
            setSyncError('Failed to reset to default data.');
        } finally {
            setIsSyncing(false);
        }
    };

    const refreshFromDatabase = async () => {
        setIsSyncing(true);
        setSyncError(null);
        try {
            const dbData = await ApiService.fetchOffers();
            setOffers(dbData);
            safeLocalStorageSet(STORAGE_KEY, dbData);
            console.log('✅ Refreshed from database');
        } catch (error) {
            console.error('❌ Failed to refresh from database:', error);
            setSyncError('Failed to refresh from database.');
        } finally {
            setIsSyncing(false);
        }
    };

    return {
        offers,
        addOffer,
        updateOffer,
        deleteOffer,
        resetToDefault,
        refreshFromDatabase,
        isLoading,
        isSyncing,
        syncError
    };
};
