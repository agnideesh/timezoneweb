﻿import { useState, useEffect, createContext, useContext, type ReactNode } from 'react';

interface AuthState {
    isAuthenticated: boolean;
    username: string | null;
}

interface AuthContextType extends AuthState {
    login: (username: string, password: string) => boolean;
    logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
    const [authState, setAuthState] = useState<AuthState>({
        isAuthenticated: false,
        username: null
    });
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const session = localStorage.getItem('adminSession');
        if (session) {
            try {
                const { username, expiry } = JSON.parse(session);
                if (Date.now() < expiry) {
                    setAuthState({ isAuthenticated: true, username });
                } else {
                    localStorage.removeItem('adminSession');
                }
            } catch (e) {
                localStorage.removeItem('adminSession');
            }
        }
        setIsLoading(false);
    }, []);

    const login = (username: string, password: string): boolean => {
        if (username === 'admin' && password === 'admin123') {
            const session = {
                username,
                expiry: Date.now() + 24 * 60 * 60 * 1000
            };
            localStorage.setItem('adminSession', JSON.stringify(session));
            setAuthState({ isAuthenticated: true, username });
            return true;
        }
        return false;
    };

    const logout = () => {
        localStorage.removeItem('adminSession');
        setAuthState({ isAuthenticated: false, username: null });
    };

    if (isLoading) {
        return null;
    }

    return (
        <AuthContext.Provider value={{ ...authState, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
