import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { type ReactNode } from 'react';
import { Login } from './components/Login';
import { WorkflowBuilder } from './components/WorkflowBuilder';
import { AuthProvider, useAuth } from './hooks/useAuth';
import './App.css';

function App() {

  return (
    <AuthProvider>
      <Router>
        <div className="app">
          <Routes>
            <Route
              path="/login"
              element={<LoginWrapper />}
            />
            <Route
              path="/builder"
              element={<RequireAuth><WorkflowBuilder /></RequireAuth>}
            />
            <Route
              path="/workflow"
              element={<RequireAuth><WorkflowBuilder /></RequireAuth>}
            />
            <Route
              path="*"
              element={<Navigate to="/workflow" replace />}
            />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

// Helper component to handle login redirect
const LoginWrapper = () => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <Navigate to="/builder" replace /> : <Login onLoginSuccess={() => { }} />;
};

// Helper component to protect routes
const RequireAuth = ({ children }: { children: ReactNode }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

export default App;
