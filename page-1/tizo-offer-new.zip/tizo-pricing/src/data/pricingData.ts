import type { PricingProduct } from '../types';

export const pricingData: PricingProduct[] = [
    {
        productName: 'Fun 100K Get 110 Tz',
        cost: 100000,
        tizoCredit: 110,
        bonusPercent: 10,
        category: 'Starter deal',
        remarks: '',
        cardType: 'New',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Fun 150K Get 180 Tz',
        cost: 150000,
        tizoCredit: 180,
        bonusPercent: 20,
        category: 'Starter deal',
        remarks: '',
        cardType: 'Blue',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3']
    },
    {
        productName: 'Fun 200K Get 260 Tz',
        cost: 200000,
        tizoCredit: 240,
        bonusPercent: 20,
        category: 'booster',
        remarks: '',
        cardType: 'Gold',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Voucher 100 get 150',
        cost: 100000,
        tizoCredit: 150,
        bonusPercent: 50,
        category: 'Power deal',
        remarks: '',
        cardType: 'Red',
        venue: ['Kiosk 1', 'Kiosk 2']
    },
    {
        productName: 'Fun 300K Get 450 Tz',
        cost: 300000,
        tizoCredit: 450,
        bonusPercent: 50,
        category: 'Power deal',
        remarks: '',
        cardType: 'Platinum',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Fun 400K Get 650 Tz',
        cost: 400000,
        tizoCredit: 650,
        bonusPercent: 62.5,
        category: 'Power deal',
        remarks: '',
        cardType: 'Gold',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Best Deal 600 get 1080',
        cost: 600000,
        tizoCredit: 1080,
        bonusPercent: 80,
        category: 'Mega deal',
        remarks: 'Not available nation wide',
        cardType: 'New',
        venue: ['Kiosk 1', 'Kiosk 3', 'Kiosk 5']
    },
    {
        productName: 'Super Best Deal 600 get 1200',
        cost: 600000,
        tizoCredit: 1200,
        bonusPercent: 100,
        category: 'Mega deal',
        remarks: 'Not available nation wide',
        cardType: 'Platinum',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3']
    },
    {
        productName: 'Best Deal 2000 get 3600',
        cost: 2000000,
        tizoCredit: 3600,
        bonusPercent: 80,
        category: 'Mega deal',
        remarks: 'Not available nation wide',
        cardType: 'Gold',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Super Best Deal 2000 get 4000',
        cost: 2000000,
        tizoCredit: 4000,
        bonusPercent: 100,
        category: 'Mega deal',
        remarks: 'Not available nation wide',
        cardType: 'Platinum',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Fun 250K Get 350 Tz',
        cost: 250000,
        tizoCredit: 350,
        bonusPercent: 40,
        category: 'Voucher',
        remarks: '',
        cardType: 'Blue',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Starlight Sprint! 400 Tizo next hour only',
        cost: 400000,
        tizoCredit: 400,
        bonusPercent: 0,
        category: 'OOD/OOH/Xmas deal',
        remarks: 'Offer of the Hour - Urgency promo',
        cardType: 'New',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Comet Claus Arrives! 400K get 750 Tz + Xmas Gift',
        cost: 400000,
        tizoCredit: 750,
        bonusPercent: 87.5,
        category: 'OOD/OOH/Xmas deal',
        remarks: 'Christmas Special - Limited Bundle',
        cardType: 'Red',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    },
    {
        productName: 'Galactic Boost! 600K gets 1350 Tizo',
        cost: 600000,
        tizoCredit: 1350,
        bonusPercent: 125,
        category: 'OOD/OOH/Xmas deal',
        remarks: 'Offer of the Day - 2X value',
        cardType: 'Platinum',
        venue: ['Kiosk 1', 'Kiosk 2', 'Kiosk 3', 'Kiosk 4', 'Kiosk 5']
    }
];

export const categories = [
    'All',
    'Starter deal',
    'booster',
    'Power deal',
    'Mega deal',
    'Voucher',
    'OOD/OOH/Xmas deal'
];
