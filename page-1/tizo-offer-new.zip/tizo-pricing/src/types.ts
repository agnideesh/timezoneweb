export interface PricingProduct {
    id?: number; // Database ID (optional for new records)
    productName: string;
    cost: number;
    tizoCredit: number;
    bonusPercent: number;
    category: string;
    cardType: string;
    venue: string[];
    startDate?: string;
    endDate?: string;
    gift?: string; // Nil, Free Gift, Free Games, Free Etickets
    giftDetails?: string; // Details based on gift type
    topLeftIcon?: string;
    topRightIcon?: string;
    bottomLeftIcon?: string;
    bottomRightIcon?: string;
    offerCardImage?: string; // Base64 image of the preview card
    isActive?: boolean; // Active/Inactive status (default: true)
}

export type CategoryType =
    | 'Voucher'
    | 'OOD'
    | 'OOH'
    | 'Seasonal'
    | 'Scratch Card'
    | 'All';

export type GiftType = 'Nil' | 'Free Gift' | 'Free Games' | 'Free Etickets';

export type CardType = 'Red' | 'Blue' | 'Gold' | 'Platinum';

export type Venue = 'Kiosk 1' | 'Kiosk 2' | 'Kiosk 3' | 'Kiosk 4' | 'Kiosk 5';

export interface WorkflowConfig {
    screensaver: {
        mediaUrl: string;
        activeHoursStart: string;
        activeHoursEnd: string;
    };
    welcome: {
        languages: string[];
        tapToStartText: string;
    };
    cardSelection: {
        enabledCards: string[];
    };
    topUp: {
        layout: 'triangle' | 'x' | 'y';
        offerCount: 3 | 4 | 5;
    };
    upsell: {
        scratchCardEnabled: boolean;
        scratchCardOffer: string;
    };
}
