-- Migration: Add is_active column to offers table
-- Created: 2025-12-08

-- Add is_active column with default true (active)
ALTER TABLE public.offers 
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

-- Update existing offers to be active
UPDATE public.offers SET is_active = true WHERE is_active IS NULL;
