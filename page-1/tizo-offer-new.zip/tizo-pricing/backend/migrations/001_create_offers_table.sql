-- Create offers table
CREATE TABLE IF NOT EXISTS offers (
    id SERIAL PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    cost NUMERIC(10, 2) NOT NULL,
    bonus_percent NUMERIC(5, 2) DEFAULT 0,
    tizo_credit NUMERIC(10, 2) NOT NULL,
    category VARCHAR(100),
    start_date DATE,
    end_date DATE,
    card_type VARCHAR(100),
    venue TEXT[],
    remarks TEXT,
    offer_card_image TEXT,
    character_icon TEXT,
    celebration_icon TEXT,
    bottom_left_icon TEXT,
    bottom_right_icon TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index on category for faster filtering
CREATE INDEX IF NOT EXISTS idx_offers_category ON offers(category);

-- Create index on dates for date range queries
CREATE INDEX IF NOT EXISTS idx_offers_dates ON offers(start_date, end_date);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_offers_updated_at 
    BEFORE UPDATE ON offers
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
