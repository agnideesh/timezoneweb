-- Migration: Add dropdown options tables
-- Created: 2025-12-07

-- ============================================
-- Table: topup_values (Top Up Value IDR options)
-- ============================================
CREATE TABLE IF NOT EXISTS public.topup_values (
    id SERIAL PRIMARY KEY,
    value INTEGER NOT NULL UNIQUE,
    is_active BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Trigger for updated_at
CREATE TRIGGER update_topup_values_updated_at 
    BEFORE UPDATE ON public.topup_values 
    FOR EACH ROW 
    EXECUTE FUNCTION public.update_updated_at_column();

-- Index for active values
CREATE INDEX IF NOT EXISTS idx_topup_values_active ON public.topup_values USING btree (is_active);

-- ============================================
-- Table: bonus_percent_options (% bonus Tizo options)
-- ============================================
CREATE TABLE IF NOT EXISTS public.bonus_percent_options (
    id SERIAL PRIMARY KEY,
    percent_value NUMERIC(5,2) NOT NULL UNIQUE,
    is_active BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Trigger for updated_at
CREATE TRIGGER update_bonus_percent_options_updated_at 
    BEFORE UPDATE ON public.bonus_percent_options 
    FOR EACH ROW 
    EXECUTE FUNCTION public.update_updated_at_column();

-- Index for active values
CREATE INDEX IF NOT EXISTS idx_bonus_percent_options_active ON public.bonus_percent_options USING btree (is_active);

-- ============================================
-- Seed Data: Top Up Values (1K-200K step 1K, then 250K-2.1M step 50K)
-- ============================================
INSERT INTO public.topup_values (value, sort_order) 
SELECT val, ROW_NUMBER() OVER (ORDER BY val)
FROM generate_series(1000, 200000, 1000) AS val
ON CONFLICT (value) DO NOTHING;

INSERT INTO public.topup_values (value, sort_order) 
SELECT val, 200 + ROW_NUMBER() OVER (ORDER BY val)
FROM generate_series(250000, 2100000, 50000) AS val
ON CONFLICT (value) DO NOTHING;

-- ============================================
-- Seed Data: Bonus Percent Options
-- 5% to 50% (step 5), 55% to 100% (step 5), 110% to 300% (step 10)
-- ============================================

-- 5% to 50% (step 5)
INSERT INTO public.bonus_percent_options (percent_value, sort_order)
SELECT val, ROW_NUMBER() OVER (ORDER BY val)
FROM generate_series(5, 50, 5) AS val
ON CONFLICT (percent_value) DO NOTHING;

-- 55% to 100% (step 5)
INSERT INTO public.bonus_percent_options (percent_value, sort_order)
SELECT val, 10 + ROW_NUMBER() OVER (ORDER BY val)
FROM generate_series(55, 100, 5) AS val
ON CONFLICT (percent_value) DO NOTHING;

-- 110% to 300% (step 10)
INSERT INTO public.bonus_percent_options (percent_value, sort_order)
SELECT val, 20 + ROW_NUMBER() OVER (ORDER BY val)
FROM generate_series(110, 300, 10) AS val
ON CONFLICT (percent_value) DO NOTHING;

