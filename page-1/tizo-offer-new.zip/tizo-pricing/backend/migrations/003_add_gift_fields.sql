-- Migration: Add gift and gift_details columns to offers table

-- Add gift column
ALTER TABLE offers ADD COLUMN IF NOT EXISTS gift VARCHAR(50) DEFAULT 'Nil';

-- Add gift_details column (VARCHAR)
ALTER TABLE offers ADD COLUMN IF NOT EXISTS gift_details VARCHAR(255) DEFAULT '';

-- Log the changes
DO $$
BEGIN
    RAISE NOTICE 'Migration 003: Added gift and gift_details columns (both VARCHAR)';
END $$;
