-- Migration: Fix category and card_type values
-- This migration updates any invalid category values (like 'Starter deal') to 'Voucher'
-- and updates any invalid card_type values (like 'ALL' or 'New') to 'Red'

-- Update invalid categories to 'Voucher' (default valid category)
UPDATE offers 
SET category = 'Voucher' 
WHERE category NOT IN ('Voucher', 'OOH', 'OOD', 'Scratch Card');

-- Update invalid card types to 'Red' (default valid card type)
UPDATE offers 
SET card_type = 'Red' 
WHERE card_type NOT IN ('Red', 'Blue', 'Gold', 'Platinum');

-- Log the changes
DO $$
BEGIN
    RAISE NOTICE 'Migration 002: Fixed category and card_type values';
END $$;
