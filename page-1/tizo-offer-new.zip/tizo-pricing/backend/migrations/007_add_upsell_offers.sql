-- Create upsell_offers table for "OFFER BUILDER 1st UPSELL"
CREATE TABLE IF NOT EXISTS upsell_offers (
    id SERIAL PRIMARY KEY,
    topup_rb INTEGER NOT NULL,           -- Topup in Rb/100,000
    tizo_value INTEGER NOT NULL,         -- Tizo credit value
    percent_increase INTEGER NOT NULL,   -- % increase
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index on topup_rb for faster lookups
CREATE INDEX IF NOT EXISTS idx_upsell_offers_topup ON upsell_offers(topup_rb);

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_upsell_offers_updated_at 
    BEFORE UPDATE ON upsell_offers
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Insert the upsell offers data
INSERT INTO upsell_offers (topup_rb, tizo_value, percent_increase) VALUES
    (100, 110, 10),
    (120, 140, 17),
    (150, 180, 20),
    (200, 260, 30),
    (250, 350, 40),
    (300, 450, 50),
    (350, 550, 57),
    (400, 650, 63),
    (500, 900, 80),
    (550, 1020, 85),
    (600, 1200, 100),
    (650, 1300, 100),
    (700, 1350, 93),
    (750, 1400, 87),
    (800, 1500, 88),
    (850, 1600, 88),
    (900, 1700, 89),
    (1000, 1900, 90),
    (1500, 2900, 93),
    (2000, 4000, 100);
