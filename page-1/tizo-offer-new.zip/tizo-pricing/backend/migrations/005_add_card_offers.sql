-- Migration: Add card_offers table
-- Created: 2025-12-07

-- ============================================
-- Table: card_offers (Card offer information)
-- ============================================
CREATE TABLE IF NOT EXISTS public.card_offers (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT '',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Trigger for updated_at
CREATE TRIGGER update_card_offers_updated_at 
    BEFORE UPDATE ON public.card_offers 
    FOR EACH ROW 
    EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- Seed Data: Default card offers
-- ============================================
INSERT INTO public.card_offers (id, name, description) VALUES
    ('red', 'Red (Welcome)', ''),
    ('blue', 'Blue Elite', ''),
    ('gold', 'Gold', ''),
    ('platinum', 'Platinum', '')
ON CONFLICT (id) DO NOTHING;
