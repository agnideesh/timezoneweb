import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pool from './db.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors({
    origin: function (origin, callback) {
        // Allow requests with no origin (like mobile apps or curl)
        if (!origin) return callback(null, true);

        // Allow localhost on any port and 127.0.0.1 on any port
        if (origin.match(/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/)) {
            return callback(null, true);
        }

        // Allow configured frontend URL
        if (origin === process.env.FRONTEND_URL) {
            return callback(null, true);
        }

        callback(new Error('Not allowed by CORS'));
    },
    credentials: true
}));
app.use(express.json({ limit: '50mb' })); // Support large base64 images
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', message: 'Tizo Pricing API is running' });
});

// Get Top Up Value options (for dropdown)
app.get('/api/topup-values', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT value FROM topup_values WHERE is_active = true ORDER BY sort_order, value'
        );
        const values = result.rows.map(row => row.value);
        res.json({ success: true, data: values });
    } catch (error) {
        console.error('Error fetching topup values:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get Bonus Percent options (for dropdown)
app.get('/api/bonus-percent-options', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT percent_value FROM bonus_percent_options WHERE is_active = true ORDER BY sort_order, percent_value'
        );
        const values = result.rows.map(row => parseFloat(row.percent_value));
        res.json({ success: true, data: values });
    } catch (error) {
        console.error('Error fetching bonus percent options:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get all card offers
app.get('/api/card-offers', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT * FROM card_offers WHERE is_active = true ORDER BY CASE id WHEN \'red\' THEN 1 WHEN \'blue\' THEN 2 WHEN \'gold\' THEN 3 WHEN \'platinum\' THEN 4 ELSE 5 END'
        );
        const cardOffers = result.rows.map(row => ({
            id: row.id,
            name: row.name,
            description: row.description || ''
        }));
        res.json({ success: true, data: cardOffers });
    } catch (error) {
        console.error('Error fetching card offers:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Update a card offer description
app.put('/api/card-offers/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { description } = req.body;

        const result = await pool.query(
            'UPDATE card_offers SET description = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *',
            [description, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Card offer not found' });
        }

        const row = result.rows[0];
        res.json({
            success: true,
            data: {
                id: row.id,
                name: row.name,
                description: row.description || ''
            }
        });
    } catch (error) {
        console.error('Error updating card offer:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get all offers
app.get('/api/offers', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT * FROM offers ORDER BY created_at DESC'
        );

        // Transform database format to app format
        const offers = result.rows.map(row => ({
            id: row.id,
            productName: row.product_name,
            cost: parseFloat(row.cost),
            bonusPercent: parseFloat(row.bonus_percent),
            tizoCredit: parseFloat(row.tizo_credit),
            category: row.category,
            startDate: row.start_date,
            endDate: row.end_date,
            cardType: row.card_type,
            venue: row.venue || [],
            gift: row.gift || 'Nil',
            giftDetails: row.gift_details || '',
            offerCardImage: row.offer_card_image,
            topLeftIcon: row.top_left_icon,
            topRightIcon: row.top_right_icon,
            bottomLeftIcon: row.bottom_left_icon,
            bottomRightIcon: row.bottom_right_icon,
            isActive: row.is_active !== false
        }));

        res.json({ success: true, data: offers });
    } catch (error) {
        console.error('Error fetching offers:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get single offer
app.get('/api/offers/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM offers WHERE id = $1', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Offer not found' });
        }

        const row = result.rows[0];
        const offer = {
            id: row.id,
            productName: row.product_name,
            cost: parseFloat(row.cost),
            bonusPercent: parseFloat(row.bonus_percent),
            tizoCredit: parseFloat(row.tizo_credit),
            category: row.category,
            startDate: row.start_date,
            endDate: row.end_date,
            cardType: row.card_type,
            venue: row.venue || [],
            gift: row.gift || 'Nil',
            giftDetails: row.gift_details || '',
            offerCardImage: row.offer_card_image,
            topLeftIcon: row.top_left_icon,
            topRightIcon: row.top_right_icon,
            bottomLeftIcon: row.bottom_left_icon,
            bottomRightIcon: row.bottom_right_icon,
            isActive: row.is_active !== false
        };

        res.json({ success: true, data: offer });
    } catch (error) {
        console.error('Error fetching offer:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Create new offer
app.post('/api/offers', async (req, res) => {
    try {
        const offer = req.body;

        const result = await pool.query(
            `INSERT INTO offers (
                product_name, cost, bonus_percent, tizo_credit, category,
                start_date, end_date, card_type, venue, gift, gift_details,
                offer_card_image, top_left_icon, top_right_icon,
                bottom_left_icon, bottom_right_icon
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
            RETURNING id`,
            [
                offer.productName,
                offer.cost,
                offer.bonusPercent || 0,
                offer.tizoCredit,
                offer.category,
                offer.startDate || null,
                offer.endDate || null,
                offer.cardType,
                offer.venue || [],
                offer.gift || 'Nil',
                offer.giftDetails || '',
                offer.offerCardImage || '',
                offer.topLeftIcon || '',
                offer.topRightIcon || '',
                offer.bottomLeftIcon || '',
                offer.bottomRightIcon || ''
            ]
        );

        res.json({
            success: true,
            data: { id: result.rows[0].id },
            message: 'Offer created successfully'
        });
    } catch (error) {
        console.error('Error creating offer:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Update offer
app.put('/api/offers/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const offer = req.body;

        const result = await pool.query(
            `UPDATE offers SET
                product_name = $1,
                cost = $2,
                bonus_percent = $3,
                tizo_credit = $4,
                category = $5,
                start_date = $6,
                end_date = $7,
                card_type = $8,
                venue = $9,
                gift = $10,
                gift_details = $11,
                offer_card_image = $12,
                top_left_icon = $13,
                top_right_icon = $14,
                bottom_left_icon = $15,
                bottom_right_icon = $16
            WHERE id = $17
            RETURNING id`,
            [
                offer.productName,
                offer.cost,
                offer.bonusPercent || 0,
                offer.tizoCredit,
                offer.category,
                offer.startDate || null,
                offer.endDate || null,
                offer.cardType,
                offer.venue || [],
                offer.gift || 'Nil',
                offer.giftDetails || '',
                offer.offerCardImage || '',
                offer.topLeftIcon || '',
                offer.topRightIcon || '',
                offer.bottomLeftIcon || '',
                offer.bottomRightIcon || '',
                id
            ]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Offer not found' });
        }

        res.json({
            success: true,
            message: 'Offer updated successfully'
        });
    } catch (error) {
        console.error('Error updating offer:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Toggle offer active status
app.patch('/api/offers/:id/toggle-active', async (req, res) => {
    try {
        const { id } = req.params;
        const { isActive } = req.body;

        const result = await pool.query(
            'UPDATE offers SET is_active = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING id, is_active',
            [isActive, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Offer not found' });
        }

        res.json({
            success: true,
            data: { id: result.rows[0].id, isActive: result.rows[0].is_active },
            message: `Offer ${isActive ? 'activated' : 'deactivated'} successfully`
        });
    } catch (error) {
        console.error('Error toggling offer status:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Delete offer
app.delete('/api/offers/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const result = await pool.query(
            'DELETE FROM offers WHERE id = $1 RETURNING id',
            [id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Offer not found' });
        }

        res.json({
            success: true,
            message: 'Offer deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting offer:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Bulk update (replace all offers)
app.post('/api/offers/bulk', async (req, res) => {
    const client = await pool.connect();

    try {
        const offers = req.body;

        await client.query('BEGIN');

        // Delete all existing offers
        await client.query('DELETE FROM offers');

        // Insert all new offers
        for (const offer of offers) {
            await client.query(
                `INSERT INTO offers (
                    product_name, cost, bonus_percent, tizo_credit, category,
                    start_date, end_date, card_type, venue, gift, gift_details,
                    offer_card_image, top_left_icon, top_right_icon,
                    bottom_left_icon, bottom_right_icon
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)`,
                [
                    offer.productName,
                    offer.cost,
                    offer.bonusPercent || 0,
                    offer.tizoCredit,
                    offer.category,
                    offer.startDate || null,
                    offer.endDate || null,
                    offer.cardType,
                    offer.venue || [],
                    offer.gift || 'Nil',
                    offer.giftDetails || '',
                    offer.offerCardImage || '',
                    offer.topLeftIcon || '',
                    offer.topRightIcon || '',
                    offer.bottomLeftIcon || '',
                    offer.bottomRightIcon || ''
                ]
            );
        }

        await client.query('COMMIT');

        res.json({
            success: true,
            message: `Bulk update completed: ${offers.length} offers`,
            count: offers.length
        });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error in bulk update:', error);
        res.status(500).json({ success: false, error: error.message });
    } finally {
        client.release();
    }
});

// Fix category and card_type values endpoint
app.post('/api/fix-data', async (req, res) => {
    try {
        // Update invalid categories to 'Voucher'
        const categoryResult = await pool.query(
            `UPDATE offers 
             SET category = 'Voucher' 
             WHERE category NOT IN ('Voucher', 'OOH', 'OOD', 'Seasonal', 'Scratch Card')
             RETURNING id`
        );

        // Update invalid card types to 'Red'
        const cardTypeResult = await pool.query(
            `UPDATE offers 
             SET card_type = 'Red' 
             WHERE card_type NOT IN ('Red', 'Blue', 'Gold', 'Platinum')
             RETURNING id`
        );

        res.json({
            success: true,
            message: 'Data fixed successfully',
            categoriesFixed: categoryResult.rowCount,
            cardTypesFixed: cardTypeResult.rowCount
        });
    } catch (error) {
        console.error('Error fixing data:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Add gift columns migration endpoint
app.post('/api/migrate-gift-columns', async (req, res) => {
    try {
        // Add gift column if not exists
        await pool.query(`
            ALTER TABLE offers ADD COLUMN IF NOT EXISTS gift VARCHAR(50) DEFAULT 'Nil'
        `);

        // Add gift_details column if not exists (VARCHAR)
        await pool.query(`
            ALTER TABLE offers ADD COLUMN IF NOT EXISTS gift_details VARCHAR(255) DEFAULT ''
        `);

        // If gift_details exists as TEXT, alter it to VARCHAR
        await pool.query(`
            ALTER TABLE offers ALTER COLUMN gift_details TYPE VARCHAR(255)
        `);

        res.json({
            success: true,
            message: 'Gift columns added successfully'
        });
    } catch (error) {
        console.error('Error adding gift columns:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`\n🚀 Tizo Pricing API Server`);
    console.log(`📡 Running on: http://localhost:${PORT}`);
    console.log(`🗄️  Database: ${process.env.DB_NAME || 'tizo_pricing'}`);
    console.log(`🌐 CORS enabled for: ${process.env.FRONTEND_URL || 'http://localhost:5173'}\n`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM signal received: closing HTTP server');
    pool.end(() => {
        console.log('Database pool closed');
        process.exit(0);
    });
});
