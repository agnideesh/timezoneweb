import pool from '../db.js';

async function checkImages() {
    try {
        const query = `
            SELECT 
                id,
                product_name,
                CASE 
                    WHEN offer_card_image IS NULL OR offer_card_image = '' THEN 'No'
                    ELSE 'Yes'
                END AS has_image,
                LENGTH(offer_card_image) AS image_length
            FROM offers
            ORDER BY id DESC
            LIMIT 5;
        `;

        const result = await pool.query(query);
        console.log('Recent offers:');
        result.rows.forEach(row => {
            console.log(`ID: ${row.id} | Product: ${row.product_name} | Has Image: ${row.has_image} | Image Length: ${row.image_length}`);
        });
    } catch (error) {
        console.error('Error checking images:', error.message);
    } finally {
        await pool.end();
    }
}

checkImages();
